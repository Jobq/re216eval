jalon4

fonction /send : /send <user> <file_name> (sans guillemets)

