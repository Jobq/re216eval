différentes couleurs pour les /msg et /msgall (automatique)

ajout de la fontionnalité channel privé
/createp <nom_channel> <mot_de_passe> 
/join <nom_channel> <mot_de_passe>
