ajout d'un historique par salon ainsi que d'un historique par client détaillant les salon qu'il a rejoint.
L'historique par salon s'affiche à chaque fois qu'un client rejoint le salon en question.
L'historique des salons d'un client se teste grâce à la commande /hist
