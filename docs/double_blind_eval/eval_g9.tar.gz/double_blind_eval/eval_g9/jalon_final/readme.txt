jalon4

Pour la fonction /quit on peut directement quitter un serveur même si on est encore dans un salon. De plus, le serveur nous fait quitter le salon actuel.
Pour quitter un salon faire la commande /quit <nom_salon>
