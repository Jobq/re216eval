#ifndef SALONS_H_
#define SALONS_H_

char* verif_salon_name(char * commande);

#endif /* SALONS */
