jalon1


Le travail a été diviser selon le client/serveur

le code serveur n'est pas fonctionnel après le jalon1, lors de la phase d'évaluation par les autres binômes seul le jalon1 pourra être évalué les profs sont au courant, ainsi les executable du code sont seulement ceux du jalon 1 qui contiennent le code entièrement développé par notre binôme


Pour les profs: 
le code client fonctionnel à été fait jusqu'au jalon 3, le code serveur d'un autre groupe a été utilisé pour vérifié que le jalon  2 et 3 fonctionne le code 

