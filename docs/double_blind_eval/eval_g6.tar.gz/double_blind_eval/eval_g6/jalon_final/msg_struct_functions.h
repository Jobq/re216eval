#ifndef MSG_STRUCT_FUNCTIONS_H_
#define MSG_STRUCT_FUNCTIONS_H_

char* get_nicksender(struct message *msg_struct);
void print_msg_content(struct message *msg_struct);

#endif /* MSG_STRUCT_FUNCTIONS_H_ */