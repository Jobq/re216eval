#include <time.h>

#ifndef BLOC_FUNCTIONS_H_
#define BLOC_FUNCTIONS_H_



struct bloc_sockaddr {
    struct sockaddr_in* saddr_out;
    struct tm* tm;
    int fd;
    char nickname[NICK_LEN];
    struct message *msg_struct;
    char channel[CHANNEL_LEN];
    struct bloc_sockaddr *next;

};

struct sockaddr_in* get_info_bloc_sockaddr(struct bloc_sockaddr *bloc);
int get_fd_bloc_sockaddr(struct bloc_sockaddr *bloc);
char* get_nickname_bloc_sockaddr(struct bloc_sockaddr *bloc);

struct message* get_msg_struct(struct bloc_sockaddr *bloc);
char* get_bloc_channel(struct bloc_sockaddr *bloc);
struct bloc_sockaddr* get_next_bloc(struct bloc_sockaddr *bloc);
void set_next_bloc(struct bloc_sockaddr *bloc, struct bloc_sockaddr *next_bloc);

void set_bloc_channel(struct bloc_sockaddr *bloc, char *channel);

#endif /* BLOC_FUNCTIONS_H_ */
