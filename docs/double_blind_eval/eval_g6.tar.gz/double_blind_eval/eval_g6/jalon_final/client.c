#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include "msg_struct.h"
#include "list_functions.h"
#include "bloc_functions.h"
#include "msg_struct_functions.h"
#include "client_functions.h"
#include <time.h>

// #define PORT 8080
#define MSG_LEN 1024


int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s IP_address Port\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    int sockfd; //sfd, s;
    char buffer_send[MSG_LEN];
    char buffer_recv[MSG_LEN];
    char pseudo[NICK_LEN];

    /* Initialisation de la structure message */

      struct message *msg_struct = malloc(sizeof(msg_struct));
    /* Fin de l'initialisation */


    struct sockaddr_in servaddr;
    int n = 0;
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0) ) < 0 ) {
        perror("Socket init...FAILED");
        exit(EXIT_FAILURE);
    } else {
        printf("Socket init ...OK\n");
    }
    memset(& servaddr, 0, sizeof(servaddr));


    // Filling client information

    if ( (atoi(argv[2]) < 1024) || (atoi(argv[2]) > 49151) ){ //range des ports enregistrés
      perror("Port out of range");
    }
    else {
      printf("Port...OK\n");
    }
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[2]));

    if ( inet_aton((const char*)argv[1], &servaddr.sin_addr) < 0 ){
      perror("Uncorrect IP address");
    }
    else {
      printf("IP address...OK\n");
    }

  // Connexion

    if ( connect(sockfd, (const struct sockaddr *) &servaddr, sizeof(servaddr)) < 0 ){
        perror("Connection...FAILED");
        exit(EXIT_FAILURE);
    } else {
        printf(("Connection...OK\n"));
    }

    while (1) {

      //Cleaning memory
      memset(msg_struct->infos, 0, INFOS_LEN);
      memset(buffer_send,0,MSG_LEN);
      memset(buffer_recv,0,MSG_LEN);


      // Getting message from client

  		fprintf(stdout, "Message: ");
  		n = 0;
  		while ((buffer_send[n++] = getchar()) != '\n') {}


      //Filling message structure
      msg_struct->pld_len = strlen(buffer_send);
      if (  get_command(buffer_send, msg_struct)  < 0 ) {
        return 0;
      }

      //Debug
  		//fprintf(stdout, "pld_len filled, pld_len = %d\n ", msg_struct->pld_len);
      //print_msg_content(msg_struct);

      //Send/receive
      send_data(sockfd, buffer_send, msg_struct);
      receive(sockfd, buffer_recv, msg_struct);

      //printf("%s\n",buffer_send );

    }
    return 0;
}
