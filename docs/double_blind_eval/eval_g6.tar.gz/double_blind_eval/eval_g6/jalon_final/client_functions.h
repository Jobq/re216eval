#ifndef CLIENT_FUNCTIONS_H_
#define CLIENT_FUNCTIONS_H_


#define MSG_LEN 1024

int send_data(int socket, char* buffer_send, struct message* msg_struct);

void receive(int socket, void* buffer_recv,  struct message* msg_struct);

int fill_type_client (char *command, char *infos, char *buffer, struct message *msg_struct);

int get_command(char *buffer, struct message *msg_struct);


#endif /* CLIENT_FUNCTIONS_H_ */