#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <net/if.h>
#include <poll.h>
#include "msg_struct.h"
#include "list_functions.h"
#include "bloc_functions.h"
#include "msg_struct_functions.h"
#include "server_functions.h"
#include "client_functions.h"
#include <time.h>

// #define PORT 8080
// #define BUFLEN 1024
// #define MAXCLIENTS 25




int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s Port\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    int sockfd;
    char buffer_recv[BUFLEN];
    struct sockaddr_in servaddr;
    /* Initialisation de la liste chaînée */
            struct bloc_sockaddr *init = malloc(sizeof(struct bloc_sockaddr*));
                if (!init)
                    perror("Memory error : init");
                init->saddr_out = NULL;
                init->fd = -1;
                init->msg_struct = NULL;
                init->next = NULL;
            //struct block_sockaddr *listbloc_pt = init;
            struct list_bloc *list = malloc(sizeof(struct list_bloc*));
            //fprintf(stdout,"list declared\n");
            list->first = init;
            list->nb_blocs = 1;
            //memset(list->channel_list, 0, sizeof(list->channel_list));
            //fprintf(stdout,"first elt introduced\n");
    /* Fin de l'initialisation */
    struct pollfd pollfds[MAXCLIENTS];

    char answer[BUFLEN];

    memset(answer,0,BUFLEN);
    memset(& pollfds, 0, sizeof(pollfds));


    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0) ) < 0 ) {
        perror("socket()");
        exit(EXIT_FAILURE);
    }
    init->fd = sockfd; // Le premier bloc de la liste correspond à la socket côté serveur


    memset(& servaddr, 0, sizeof(servaddr));


    // Filling server information
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    inet_aton("127.0.0.1", & servaddr.sin_addr);

    //Bind
    if ( bind( sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr) ) == -1 ) {
        perror("Binding ...FAILED");
        exit(EXIT_FAILURE);
    } else {
        printf("Binding ...OK\n");
    }

    //Listen
    if (listen ( sockfd, SOMAXCONN ) == -1 ) {
        perror("Listening ...FAILED");
        exit( EXIT_FAILURE );
    } else {
        printf("Listening ...OK\n");
    }

    pollfds[0].fd = sockfd;
    pollfds[0].events  = POLLIN;
    int nfds = 1; // nb de descripteur de fichiers actuels correspondant à des sockets côté serveur
    int timeout = 2000;
    int i;
    while (1){

        if (    (get_list_nb_blocs(list) < nfds) && (pollfds[nfds-1].fd == 0)   )
        /* On décrémente nfds si le nombre de sockets côté serveur est inférieur à nfds
            et à condition que pollfds[nfds-1].fd ne soit pas occupé */
            --nfds;

        for ( i = 0 ;  i < nfds ;  i++ ) {
            if ( poll(pollfds, nfds, timeout) < 0 ) {
                perror("Poll...FAILED");
                exit(EXIT_FAILURE);
            }
            if (pollfds[i].revents == POLLIN) {
                /* On se positionne au bon maillon de la liste chaînée */
                    struct bloc_sockaddr *bloc_addr = get_list_bloc(list);
                    while( get_next_bloc(bloc_addr) != NULL) {
                        bloc_addr = bloc_addr->next;
                }
                /* Fin du positionnement */
                if ( (pollfds[i].fd == sockfd) && (get_list_nb_blocs(list) < MAXCLIENTS) ) {

                    /* On prépare la structure saddr_out, qui contiendra les informations de la socket client*/
                        struct sockaddr_in saddr_out_tmp;
                        struct message *msg_struct = malloc(sizeof(struct message));
                        memset(& saddr_out_tmp, 0, sizeof(saddr_out_tmp));
                        memset(msg_struct, 0, sizeof(struct message));
                        int size_sock2 = sizeof(saddr_out_tmp);
                    /* Fin de la préparation de saddr_out */


                    /* On initialise le nouveau maillon de la liste chaînée */
                        struct bloc_sockaddr *bloc_addr_new = malloc(sizeof(struct bloc_sockaddr));
                        bloc_addr_new->saddr_out = &saddr_out_tmp;
                        time_t rawtime;
                        time(&rawtime);
                        bloc_addr_new->tm = localtime(&rawtime);
                        bloc_addr_new->fd = -1;
                        memset(bloc_addr_new->nickname, 0, NICK_LEN);
                        memset(bloc_addr_new->channel, 0, CHANNEL_LEN);
                        bloc_addr_new->msg_struct = msg_struct;
                        bloc_addr_new->next = NULL;
                    /* Fin de l'initialisation */


                    /* On remplit puis on insère le nouveau maillon de la liste chaînée */
                        int sock2 = accept( sockfd, (struct sockaddr*) get_info_bloc_sockaddr(bloc_addr_new), (socklen_t*) &size_sock2 );
                        bloc_addr_new->fd = sock2;
                        //bloc_addr->next = malloc(sizeof(struct bloc_sockaddr*));
                        bloc_addr->next = &(*bloc_addr_new);
                        list->nb_blocs += 1;
                    /* Fin de l'insertion */

                    if (sock2 == -1)
                    {
                        perror("Accept...FAILED");
                        exit(EXIT_FAILURE);
                    }
                    else
                    {
                        nfds++;
                        memset(& pollfds[nfds-1].fd, 0, sizeof(pollfds[i].fd));
                        memset(& pollfds[nfds-1].events, 0, sizeof(pollfds[i].events));
                        fill_pollfd(pollfds, nfds, sock2);

                        //printf("pollfds[nfds-1] : %d\n ", pollfds[nfds-1].fd);
                        printf("Accept...OK\n");
                            if (get_next_bloc(get_list_bloc(list)) == NULL) {
                                //printf("first->next is NULL after adding\n");
                            }
                            else {
                                //printf("first->next is NOT NULL after adding and fd = %d\n",
                                get_fd_bloc_sockaddr(get_next_bloc(get_list_bloc(list)));
                                //print_list_bloc(list);
                            }
                    }
                }
                else{


                    struct bloc_sockaddr *current_bloc = get_list_bloc(list);
                    while (   (current_bloc != NULL)
                         && (get_fd_bloc_sockaddr(current_bloc) != pollfds[i].fd)   ) {
                        /* On se déplace dans la liste jusqu'à ce qu'on arrive sur le bloc
                            correspondant au client courant */
                        current_bloc = get_next_bloc(current_bloc);
                    }
                    if (current_bloc == NULL) {
                        perror("Erreur : client courant non trouvé");
                    }

                    memset(buffer_recv,0,BUFLEN);
                    memset(current_bloc->msg_struct,0,sizeof(struct message));


                    // Receiving structure
                    int ret1 = recv(pollfds[i].fd, (void*) current_bloc->msg_struct, (size_t) sizeof(struct message), 0);

                    //fprintf(stdout, "msg_struct received by server : \n");
                    print_msg_content(current_bloc->msg_struct);



                    // Receiving buffer
                    int ret2 = recv(pollfds[i].fd, (char*) buffer_recv, (size_t) BUFLEN, 0);
                    //fprintf(stdout, "buffer received by server : %s\n", buffer_recv);

                    //sleep(2); // Test de la gestion de la saisie de message
                    //et de la réception en même temps par le client (Req1.5)


                    if (ret1 < 0) {
                        perror("Recv structure...FAILED");
                        exit(EXIT_FAILURE);
                    }

                    if (ret2 < 0) {
                        perror("Recv buffer...FAILED");
                        exit(EXIT_FAILURE);
                    }

                    if (!strcmp(buffer_recv, "/quit\n")) {
                        ret2 = 0;
                    }

                    else if ( ( ret1 > 0) && (ret2 > 0)  )
                    {
                        memset(answer,0,BUFLEN);
                        fill_type_server( list, current_bloc, current_bloc->msg_struct,answer,buffer_recv );
                        printf("[ Client %s ] :  %s \n", current_bloc->nickname, buffer_recv );


                        // Sending structure and buffer to client(s)


                        if (current_bloc->msg_struct->type == BROADCAST_SEND) {
                            for ( int i = 0 ;  i < nfds ;  i++ ) {
                                if ( (pollfds[i].revents == POLLIN) && (pollfds[i].fd != current_bloc->fd) ){
                                    printf("Broadcast Sending to client\n");
                                    send_to_client(pollfds[i].fd, answer, current_bloc);
                                }
                            }
                          }
                        else if (current_bloc->msg_struct->type == UNICAST_SEND) {
                            struct bloc_sockaddr *bloc = get_list_bloc(list);
                            while (bloc != NULL) {
                                if ( strcmp(bloc->nickname, current_bloc->msg_struct->infos) == 0) {
                                    for ( int i = 0 ;  i < nfds ;  i++ ) {
                                        if (pollfds[i].revents == POLLIN) {
                                            if (bloc->fd == pollfds[i].fd) {
                                                printf("Unicast Sending to client\n");
                                                send_to_client(pollfds[i].fd, answer, current_bloc);
                                            }
                                        }
                                    }
                                }
                            }
                            bloc = get_next_bloc(bloc);
                        }
                        else {
                        send_to_client(pollfds[i].fd, answer, current_bloc);
                        }

                    }
                    else if ( ( ( ret2 == 0 ) || (ret1 == 0) ) && (get_list_bloc(list) != NULL) ) {

                    supprimer_client(list, pollfds[i].fd);

                    memset(& pollfds[i].fd, 0, sizeof(pollfds[i].fd));
                    memset(& pollfds[i].events, 0, sizeof(pollfds[i].events));
                    //memset(& pollfds[i].revents, 0, sizeof(pollfds[i].revents));
                    fprintf(stdout, "Client number %d has left the chat.\n\n", i);
                    //fprintf(stdout, "nfds = %d\n", nfds);
                    }

                } // if ( (pollfds[i].fd == sockfd) && (get_list_nb_blocs(list) < MAXCLIENTS) ) { ... } else { ...
            } // if pollfds[i].events == POLLIN
        } // boucle for sur pollfds
    } // while (1)
} // int main
