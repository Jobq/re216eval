int get_command(char *buffer, struct message *msg_struct);
