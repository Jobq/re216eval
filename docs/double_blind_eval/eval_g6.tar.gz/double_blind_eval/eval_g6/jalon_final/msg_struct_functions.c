#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include "msg_struct.h"

char* get_nicksender(struct message *msg_struct){
  return(msg_struct->nick_sender);
}


void print_msg_content(struct message *msg_struct) {
    if (msg_struct == NULL)  {
        fprintf(stdout, "msg_struct is NULL\n");
    }
    else {
        fprintf(stdout, " - - - - \nstruct message {\n");
        fprintf(stdout, "   int pld_len = %d\n", msg_struct->pld_len);
        fprintf(stdout, "   char nick_sender[] = %s\n", msg_struct->nick_sender);
        fprintf(stdout, "   enum msg_type type = %s\n", msg_type_str[msg_struct->type]);
        fprintf(stdout, "   char infos[] = %s\n}; - - - - \n\n", msg_struct->infos);
    }
}
