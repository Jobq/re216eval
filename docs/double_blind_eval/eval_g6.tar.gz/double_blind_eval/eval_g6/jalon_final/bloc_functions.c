#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "msg_struct.h"
#include "bloc_functions.h"


/*
struct bloc_sockaddr {
    struct sockaddr_in* saddr_out;
    int fd;
    char nickname[NICK_LEN];
    struct message *msg_struct;
    struct bloc_sockaddr *next;
};
*/

struct sockaddr_in* get_info_bloc_sockaddr(struct bloc_sockaddr *bloc) {
    if (bloc == NULL) {
        fprintf(stdout, "Error in get_info_bloc_sockaddr : parameter is NULL\n");
        return NULL;
    }
    return bloc->saddr_out;
}


int get_fd_bloc_sockaddr(struct bloc_sockaddr *bloc) {
    if (bloc == NULL) {
        fprintf(stdout, "Error in get_fd_bloc_sockaddr : parameter is NULL\n");
        return -2;
    }
    return bloc->fd;
}

char* get_nickname_bloc_sockaddr(struct bloc_sockaddr *bloc) {
    if (bloc == NULL) {
        fprintf(stdout, "No nickname for this Client\n");
        return NULL;
    }
    return bloc->nickname;
}


struct message* get_msg_struct(struct bloc_sockaddr *bloc){
    if (bloc == NULL) {
        return NULL;
    }
    return(bloc->msg_struct);
}

char* get_bloc_channel(struct bloc_sockaddr *bloc) {
    if (bloc == NULL) {
        fprintf(stdout, "No nickname for this Client\n");
        return NULL;
    }
    return bloc->channel;
}

void set_bloc_channel(struct bloc_sockaddr *bloc, char *channel){
  strcpy(bloc->channel, channel);
}

struct bloc_sockaddr* get_next_bloc(struct bloc_sockaddr *bloc) {
    if (bloc == NULL) {
        return bloc;
    }
    return bloc->next;
}

void set_next_bloc(struct bloc_sockaddr *bloc, struct bloc_sockaddr *next_bloc) {
    /* Setting up the next bloc of bloc as next_bloc */
    if (bloc == NULL) {
        //fprintf(stdout, "Argument of function set_next_bloc is NULL\n");
    }
    else if (next_bloc == NULL) {
        bloc->next = NULL;
    }
    else {
        bloc->next = & (*(next_bloc));
    }
}
