# RE216 - Projet de programmation réseau

Compilation :
make client
make serveur

Execution :
./serveur port_number
./client IP_address port_number

port_number = 8080
IP_address = 127.0.0.1
