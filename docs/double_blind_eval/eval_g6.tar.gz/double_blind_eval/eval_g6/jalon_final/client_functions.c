#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <net/if.h>
#include "msg_struct.h"
#include "list_functions.h"
#include "bloc_functions.h"
#include "msg_struct_functions.h"
#include "client_functions.h"


int send_data(int socket, char* buffer_send, struct message* msg_struct) {

      //fprintf(stdout, "Inside function send_data, buffer send is : %s\n ", (char *) buffer_send);
      print_msg_content(msg_struct);
        int s1,s2;

        // Sending structure (ECHO)
        if ( (s1 = send(socket, (const void*) msg_struct, (size_t) sizeof(struct message) , 0)) <= 0 ) {
            perror("Struct message sending ... FAILED");
            exit(EXIT_FAILURE);
        }

        // Sending buffer (ECHO)
        //fprintf(stdout, "Before sending buffer : msg_struct->pld_len = %d\n", msg_struct->pld_len);
        if ( (s2 = send(socket, (const void*) buffer_send, (size_t) msg_struct->pld_len, 0 )) <= 0 )   {
            perror("Buffer sending ... FAILED");
            //exit(EXIT_FAILURE);
        }

        memset(buffer_send,0,MSG_LEN);
        memset(msg_struct, 0, sizeof(struct message));
        //fprintf(stdout, "%d + %d bytes sent by send_data\n", s1, s2);
        return s1+s2;
}

void receive(int socket, void* buffer_recv,  struct message* msg_struct) {
    memset(buffer_recv,0,MSG_LEN);
    memset(msg_struct, 0, sizeof(struct message));
    int rv1,rv2;

    // Receiving structure (ECHO)
    if ( (rv1 = recv(socket, msg_struct, sizeof(struct message) , 0)) <= 0 ) {
        //printf("recv structure return value : %d\n", rv1);
        perror("recv()");
        exit(EXIT_FAILURE);
    }
    else {
        //printf("Serveur structure : \n");
        print_msg_content(msg_struct);
    }

    // Receiving buffer (ECHO)
    if ( (rv2 = recv(socket, buffer_recv, msg_struct->pld_len, 0 )) <= 0 ) {
        //printf("recv buffer return value : %d\n", rv2);
        perror("recv()");
        exit(EXIT_FAILURE);
    }
    else {
        if ( strcmp(msg_struct->nick_sender, " ") == 0 ) {
            /* Un pseudo client  ne peut commencer par un espace */
            /* De plus lors de la réponse du serveur, son champ nick_sender est égal à " " */
            /* Donc si le champ nick_sender contient " ", la réponse vient nécessairement du serveur */

            fprintf(stdout, "[ Serveur ] : %s\n", (char *)buffer_recv);
        }
        else {
            fprintf(stdout, "[ %s ] : %s\n", msg_struct->nick_sender, (char *)buffer_recv);
        }
    }
}

int fill_type_client (char *command, char *infos, char *buffer, struct message *msg_struct) {
    /* Remplit correctement le champ type selon la commande donnée */
    /* Retour : entier fill (vaut 1 si la commande est valide, 0 sinon) */
    int fill = 0;
    //fprintf(stdout, "Entrée dans fill_type_client. command = %s\n", command);
    if (!strcmp(command, "/nick")) {
        msg_struct->type = NICKNAME_NEW;
        memset(msg_struct->nick_sender, 0, NICK_LEN);
        strncpy(msg_struct->nick_sender, infos, strlen(infos));
        fill = 1;
    }
    else if (!strcmp(command, "/who")) {
        msg_struct->type = NICKNAME_LIST;
        fill = 1;

    }
    else if (!strcmp(command, "/whois")) {
        msg_struct->type = NICKNAME_INFOS;
        strncpy(msg_struct->infos, infos, strlen(infos));
        fill = 1;
    }
    else if (!strcmp(command, "/msgall")) {
        msg_struct->type = BROADCAST_SEND;
        strncpy(msg_struct->infos, infos, strlen(infos));
        fill = 1;
    }
    else if (!strcmp(command, "/msg")) {
        msg_struct->type = UNICAST_SEND;
        fill = 1;
    }
    else if (strcmp(command, "/quit") == 0) {
        if (strcmp(infos, "\0") == 0){
            printf("Exiting chat...\n");
            free(msg_struct);
            sleep(1);
            return -1;
        }
        else {
            msg_struct->type = MULTICAST_QUIT;
            strncpy(msg_struct->infos,infos,strlen(infos));
            fill = 1;
        }
    }
    else if (!strcmp(command, "/create")) {
        msg_struct->type = MULTICAST_CREATE;
        strncpy(msg_struct->infos,infos,strlen(infos));
        fill = 1;
    }
    else if (!strcmp(command, "/channel_list")) {
        msg_struct->type = MULTICAST_LIST;
        fill = 1;
    }
    else if (!strcmp(command, "/join")) {
        msg_struct->type = MULTICAST_JOIN;
        strncpy(msg_struct->infos,infos,strlen(infos));
        fill = 1;
    }
    else {
        msg_struct->type = ECHO_SEND;
        strncpy(msg_struct->infos, buffer, strlen(infos));

    }
    return fill;
}


int get_command(char *buffer, struct message *msg_struct){
    /* Distingue la commande du message dans le buffer */
    /* Remplit la structure message en conséquence */

    char command[INFOS_LEN];
    char infos[INFOS_LEN];
    memset(command,0,INFOS_LEN);
    memset(infos,0,INFOS_LEN);

    int i = 0;

    if (buffer[0] == '/') {
    while ( (buffer[i] != ' ') && (buffer[i] != '\n') && (i<strlen(buffer)) ) {
        command[i] = buffer[i];
        i++;
    }
    command[i] = '\0';
    int j = i+1;
    i = 0;
    while (   (buffer[j] != '\n') && (j<strlen(buffer) )   ) {
        infos[i] = buffer[j];
        //printf(" %c %c  ,  ", infos[i], buffer[i]);
        j++;
        i++;
    }
    infos[i] = '\0';

    }
    int fill_msg = fill_type_client(command, infos, buffer, msg_struct);
    if ( fill_msg > 0 ) {
        return fill_msg;
    }
    else if ( fill_msg == 0 ){ //not a command
        return fill_msg;
    }
    else { // command = "/quit"
        return fill_msg;
    }
}
