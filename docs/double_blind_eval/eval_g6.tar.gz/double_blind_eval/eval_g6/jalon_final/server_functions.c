#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <net/if.h>
#include <poll.h>
#include "msg_struct.h"
#include "list_functions.h"
#include "bloc_functions.h"
#include "msg_struct_functions.h"
#include "server_functions.h"

int freenick(struct list_bloc* list, char *new_nick) {
    /* Vérifie si le pseudo new_nick n'est pas déjà attribué */
    /* Renvoie 0 si le pseudo new_nick est déjà pris, 1 sinon */

    struct bloc_sockaddr *current_bloc = get_list_bloc(list);
    current_bloc = get_next_bloc(current_bloc);
    while( current_bloc != NULL ) {
      if ( strcmp(get_nickname_bloc_sockaddr(current_bloc),new_nick) == 0 ) {
          //printf("current_bloc->nickname :  %s, new_nick : %s\n",get_nickname_bloc_sockaddr(current_bloc),new_nick);
      return 0;
      }
      current_bloc = get_next_bloc(current_bloc);
    }
    return 1;
}

int is_channel(struct list_bloc* list, char *channel) {
  /* Vérifie la présence ou non du nom de channel sur le serveur en parcourant les blocs des clients*/
  /* Renvoie 0 si le salon existe, 1 sinon */
  struct bloc_sockaddr *current_bloc = get_list_bloc(list);
  current_bloc = get_next_bloc(current_bloc);

  while( current_bloc != NULL ) {
    if ( strcmp(get_bloc_channel(current_bloc),channel) == 0 ) {
      return 0;
    }
    current_bloc = get_next_bloc(current_bloc);
  }
  return 1;
}

int is_channel_in_list(struct list_bloc* list, char *channel){
  /* teste la présence ou non du salon sur le server en parcourant la liste des salons*/
  int i = 0;
  while (strcmp(list->channel_list[i],"\0") != 0){
    if (strcmp(list->channel_list[i], channel) == 0){
      return 0;
    }
    i++;
  }
  return 1;
}

void delete_channel(struct list_bloc* list, char* channel){
  /* Supprime le channel dans le champ channel_list des listes */
  int i = 0;
  while (strcmp(list->channel_list[i], channel) != 0){
    i++;
  }
  strcpy(list->channel_list[i],"\0");
  i++;
  while (strcmp(list->channel_list[i],"\0") != 0){
    strcpy(list->channel_list[i-1],list->channel_list[i]);
    strcpy(list->channel_list[i],list->channel_list[i+1]);
    i++;
  }
}

void add_channel(struct list_bloc* list, char* channel){
  /* Adds a channel to the list of channels */
  int i = 0;
  while (strcmp(list->channel_list[i],"\0") != 0){
    i++;
  }
  strcpy(list->channel_list[i], channel);
}


char *fill_type_server (struct list_bloc *list, struct bloc_sockaddr *current_bloc, struct message *msg_struct, char* answer, char* buffer) {
    //printf("client channel : %s\n",current_bloc->channel);
    /* Complète la liste et les blocs en fonction de message->type (msg_struct->type) */
    /* Remplit msg_struct->infos et msg_struct->pld_len */
    /* Renvoie la chaîne de caractères answer à envoyer au client */

    memset(answer, 0, INFOS_LEN);
    /* fprintf(stdout, "\nnick_sender : %s\n", msg_struct->nick_sender);
    fprintf(stdout, "\nmsg infos : %s\n", msg_struct->infos);
    fprintf(stdout, "buffer : %s\n",buffer ); */

    if (   (msg_struct->type == NICKNAME_NEW )
        && (strcmp(msg_struct->nick_sender,"\0") != 0)
        && (msg_struct->nick_sender[0] != ' ')   ) {

        if (    freenick(list, msg_struct->nick_sender) == 1  ) {
            msg_struct->type = ECHO_SEND;
            strcpy(get_nickname_bloc_sockaddr(current_bloc),msg_struct->nick_sender);
            //strcpy(msg_struct->nick_sender,current_bloc->nickname);
            sprintf(answer, "Welcome to the chat %s\n", msg_struct->nick_sender);
            //fprintf(stdout, "\nnick_sender : %s\n", msg_struct->nick_sender);
            msg_struct->pld_len = strlen(answer);
            memset(msg_struct->nick_sender, 0, NICK_LEN);
            sprintf(msg_struct->nick_sender, " ");
            //fprintf(stdout, "Answer is : %s\n", answer);
            return answer;

        }
        else {
            strcpy(answer,"Nickname already used\n");
            msg_struct->pld_len = strlen(answer);
            memset(msg_struct->nick_sender, 0, NICK_LEN);
            sprintf(msg_struct->nick_sender, " ");
            msg_struct->type = ECHO_SEND;
            return answer;
        }
    }

    else if (strcmp(get_nickname_bloc_sockaddr(current_bloc),"\0") == 0){
        strncpy(answer,"Please login with /nick <your pseudo>\n", BUFLEN);
        msg_struct->pld_len = strlen(answer);
        memset(msg_struct->nick_sender, 0, NICK_LEN);
        sprintf(msg_struct->nick_sender, " ");
        msg_struct->type = ECHO_SEND;
        //printf("Answer of length %ld is : %s", strlen(answer), answer);
        return answer;
    }

    else if ( msg_struct->type == NICKNAME_LIST) {
        char *users = malloc(sizeof(NICK_LEN*MAXCLIENTS + INFOS_LEN));
        memset(users, 0, sizeof(NICK_LEN*MAXCLIENTS + INFOS_LEN));
        struct bloc_sockaddr *bloc = get_list_bloc(list);
        bloc = get_next_bloc(bloc);

        while( bloc != NULL ) {
            sprintf(users,"%s - %s\n",users, get_nickname_bloc_sockaddr(bloc));
            bloc = get_next_bloc(bloc);
        }
        sprintf(answer,"Online users are \n%s", users);
        free(users);
        msg_struct->pld_len = strlen(answer);
        memset(msg_struct->nick_sender, 0, NICK_LEN);
        sprintf(msg_struct->nick_sender, " ");
        msg_struct->type = ECHO_SEND;
        return answer;
    }

     else if (msg_struct->type == NICKNAME_INFOS) {
        if ( (msg_struct->infos[0] != '\0') && (msg_struct->infos[0] != ' ') ) {
            struct bloc_sockaddr *bloc = get_list_bloc(list);
            while (bloc != NULL) {
            if ( strcmp(bloc->nickname, msg_struct->infos) == 0) {
                sprintf(answer,"%s connected since %d/%d/%d @%d:%d with IP address 127.0.0.1 and port number %d\n",
                bloc->nickname, bloc->tm->tm_year + 1900, bloc->tm->tm_mon + 1, bloc->tm->tm_mday, bloc->tm->tm_hour, bloc->tm->tm_min, bloc->saddr_out->sin_port);
            }
            bloc = get_next_bloc(bloc);
            }
            if (strlen(answer) == 0){
                sprintf(answer,"User %s does not exist", msg_struct->infos);
            }
            msg_struct->pld_len = strlen(answer);
            memset(msg_struct->nick_sender, 0, NICK_LEN);
            sprintf(msg_struct->nick_sender, " ");
            msg_struct->type = ECHO_SEND;
            return answer;
        }
        else {
            sprintf(answer, "Usage : /whois <pseudo>");
            msg_struct->pld_len = strlen(answer);
            memset(msg_struct->nick_sender, 0, NICK_LEN);
            sprintf(msg_struct->nick_sender, " ");
            msg_struct->type = ECHO_SEND;
            return answer;
        }
    }
    else if (msg_struct->type == BROADCAST_SEND) {
        sprintf(answer, "%s", buffer);
        msg_struct->pld_len = strlen(answer);
        memset(msg_struct->nick_sender, 0, NICK_LEN);
        sprintf(msg_struct->nick_sender, " ");
        msg_struct->type = ECHO_SEND;
        return answer;
    }
    else if (msg_struct->type == UNICAST_SEND) {
        strcpy(answer, buffer);
        msg_struct->pld_len = strlen(answer);
        memset(msg_struct->nick_sender, 0, NICK_LEN);
        sprintf(msg_struct->nick_sender, " ");
        msg_struct->type = ECHO_SEND;
        return answer;
    }
    else if(msg_struct->type == MULTICAST_CREATE) {
      if (is_channel(list, msg_struct->infos) == 0) {
        strcpy(answer,"channel name already exists\n");
      }
      else{
        if (strcmp(current_bloc->channel,"\0") == 0){
          sprintf(answer,"You have created channel %s", msg_struct->infos);
        }
        else {
          sprintf(answer,"Leaving channel %s ... You have created channel %s", current_bloc->channel, msg_struct->infos);
        }
        strcpy(current_bloc->channel,msg_struct->infos);
        add_channel(list, msg_struct->infos);
      }
      msg_struct->pld_len = strlen(answer);
      return answer;
    }
    else if (msg_struct->type == MULTICAST_LIST) {
      char *channels = malloc(sizeof(CHANNEL_LEN*MAX_CHANNEL + INFOS_LEN));
      memset(channels, 0, sizeof(CHANNEL_LEN*MAX_CHANNEL + INFOS_LEN));
      int i = 0;
      while (strcmp(list->channel_list[i],"\0") != 0) {
        if (is_channel(list, list->channel_list[i]) == 0){
          sprintf(channels,"%s - %s\n",channels, list->channel_list[i]);
        }
        i++;
      }
      sprintf(answer,"Online channels are \n%s", channels);
      free(channels);
      msg_struct->pld_len = strlen(answer);
      return answer;
    }
    else if (msg_struct->type == MULTICAST_JOIN) {
      char *old_channel = malloc(sizeof(CHANNEL_LEN));
      strcpy(old_channel,current_bloc->channel);
      if(strcmp(current_bloc->channel,msg_struct->infos) == 0) {
        sprintf(answer,"already in channel %s",msg_struct->infos);
      }
      else if (is_channel(list, msg_struct->infos) == 0) {
        if (strcmp(current_bloc->channel,"\0") == 0){
          sprintf(answer,"You have joined the channel %s\n",msg_struct->infos);
        }
        else {
          sprintf(answer,"Leaving channel %s ... You have joined channel %s\n",current_bloc->channel,msg_struct->infos);
          // if (is_channel(list, old_channel) == 1){
          //   delete_channel(list, msg_struct->infos);
          //   sprintf(answer,"%sYou were the last user on channel %s ... channel destroyed", answer, old_channel);
          // }
        }
        set_bloc_channel(current_bloc, msg_struct->infos);
      }
      else {
        sprintf(answer,"channel %s does not exist",msg_struct->infos);
      }
      free(old_channel);
      msg_struct->pld_len = strlen(answer);
      return answer;
    }
    else if (msg_struct->type == MULTICAST_SEND){
      //à compléter
    }
    else if(msg_struct->type == MULTICAST_QUIT){
      if (strcmp(current_bloc->channel,msg_struct->infos) == 0){
        sprintf(answer, "Leaving channel %s...", msg_struct->infos);
        memset(current_bloc->channel, 0, CHANNEL_LEN);
        if (is_channel(list, msg_struct->infos) == 1) {
          sprintf(answer,"%sYou have destroyed channel %s", answer, msg_struct->infos);
          delete_channel(list, msg_struct->infos);
        }
      }
      else {
        sprintf(answer,"Not in channel %s", msg_struct->infos);
      }
      msg_struct->pld_len = strlen(answer);
      return answer;
    }
    else {
    /* msg_struct->type = ECHO_SEND */
        strcpy(msg_struct->nick_sender,get_nickname_bloc_sockaddr(current_bloc));
        strcpy(answer,buffer);
        msg_struct->pld_len = strlen(answer);
        memset(msg_struct->nick_sender, 0, NICK_LEN);
        sprintf(msg_struct->nick_sender, " ");
        msg_struct->type = ECHO_SEND;
        return answer;
    }
}



void fill_pollfd(struct pollfd *pollfds, int nfds, int client_sockfd) {
    /* Fonction qui remplit la structure pollfds lorsque la socket client a été acceptée */
    int i = 1;
    while ( ( i < nfds ) ){
        if ( pollfds[i].fd == 0 ) {
            pollfds[i].fd = client_sockfd;
            pollfds[i].events = POLLIN;
            i = nfds;
            /*fprintf(stdout, "sock with fd = %d added at position %d in pollfds\n",
                    client_sockfd, i); */
        }
        ++i;
    }
}



void send_structure(int fd, struct message *msg_struct) {
    /* Fonction côté serveur qui permet d'envoyer une structure */
    if (send(fd, msg_struct, sizeof(struct message) , 0) <= 0) {
        perror("Send...FAILED");
        exit(EXIT_FAILURE);
    }

    else {
        printf("Send...OK\n");
    }
}

void send_buffer(int fd, char* buffer) {
    /* Fonction côté serveur qui permet d'envoyer un buffer */
    if (send(fd, (const void*) buffer, (size_t) strlen(buffer), 0) <= 0) {
        perror("Send...FAILED");
        exit(EXIT_FAILURE);
    }

    else {
        printf("Send...OK\n");
    }

}

void send_to_client(int fd, char *answer, struct bloc_sockaddr *current_bloc) {
    /* Fonction côté serveur qui permet d'envoyer une structure et un buffer */

    //Sending structure
    send_structure(fd, get_msg_struct(current_bloc));

    // Sending buffer
    send_buffer(fd, answer);

}

void supprimer_client(struct list_bloc *list, int client_fd) {
    /* Fonction qui permet de supprimer un client dont la socket file descriptor (fd) est connue */
    struct bloc_sockaddr *bloc_addr = get_list_bloc(list);
    int check_fd = -1;
    while( check_fd < 0 && get_next_bloc(bloc_addr) != NULL) {
        if ( client_fd != get_fd_bloc_sockaddr(get_next_bloc(bloc_addr)) ) {
            /* Le prochain bloc n'est pas celui à supprimer : on avance dans la liste */
            bloc_addr = get_next_bloc(bloc_addr);
        }
        else {
        /* Le prochain bloc est celui à supprimer : on sort de la boucle */
            check_fd = 1;
        }
    }

    if (check_fd) {
        /* On supprime le bloc concerné et on réorganise la liste  */
        delete_bloc_list(bloc_addr);
        dec_list_nb_bloc(list);
        //list->nb_blocs -= 1;
        print_list_bloc(list);
    }
     else
    {
        fprintf(stdout,
        "Erreur : descripteur de fichier du client non retrouvé dans la liste chaînée\n");
        exit(EXIT_FAILURE);
    }

}
