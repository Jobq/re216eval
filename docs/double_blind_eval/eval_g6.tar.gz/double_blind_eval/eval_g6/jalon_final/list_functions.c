#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "msg_struct.h"
#include "list_functions.h"
#include "bloc_functions.h"
#include "msg_struct_functions.h"

/*
struct list_bloc {
    struct bloc_sockaddr *first;
    int nb_blocs;  //Correspond au nombre de sockets côté clients
                   // (sockets clients + socket d'établissement de connexion) 
};
*/

struct bloc_sockaddr* get_list_bloc(struct list_bloc* list){
    if (list == NULL) {
        fprintf(stdout, "Error in get_list_bloc : argument is NULL\n");
        return NULL;
    }
    return list->first;
}


int get_list_nb_blocs(struct list_bloc* list) {
    if (list == NULL) {
        fprintf(stdout, "Error in get_list_bloc : argument is NULL\n");
        return -1;
    }
    return list->nb_blocs;
}

void inc_list_nb_bloc(struct list_bloc* list) {
    if (list == NULL) {
        fprintf(stdout, "Error in inc_list_nb_bloc : argument is NULL\n");
    }
    list->nb_blocs += 1;
}

void dec_list_nb_bloc(struct list_bloc* list){
    if (list == NULL) {
        fprintf(stdout, "Error in dec_list_nb_bloc : argument is NULL\n");
    }
    list->nb_blocs -= 1; 
}

void print_list_bloc(struct list_bloc* list) {
    if (list == NULL)  {
        fprintf(stdout, "list is NULL\n");
    }
    else if ( get_list_bloc(list) == NULL ) {
        fprintf(stdout, "First element in list is NULL\n");
    }
    else {
        struct bloc_sockaddr *current_bloc = get_list_bloc(list);
        fprintf(stdout, "\n ~~~~~~~~~~~~~~~~ \n Liste  : %d éléments     \n", list->nb_blocs);
        fprintf(stdout, "        |       \n        |       \n        V       \n");
        while( current_bloc != NULL ) {
            fprintf(stdout, "Client fd = %d\n", get_fd_bloc_sockaddr(current_bloc));
            fprintf(stdout, "Nickname : %s\n", get_nickname_bloc_sockaddr(current_bloc));
            print_msg_content(get_msg_struct(current_bloc));
            fprintf(stdout, "        |       \n        |       \n        V       \n");
            current_bloc = get_next_bloc(current_bloc);
        }
        fprintf(stdout, "       NULL       \n ~~~~~~~~~~~~~~~~ \n\n");
    }
}

void delete_bloc_list(struct bloc_sockaddr *bloc_addr) {
    /* bloc_addr est le bloc précédant le bloc à supprimer */
    /* Cette fonction supprime bloc_addr->next */

    if (get_next_bloc(get_next_bloc(bloc_addr)) != NULL) {
        /* Suppression d'un bloc en milieu de liste */
        struct bloc_sockaddr* bloc_addr_del = get_next_bloc(bloc_addr);
        close(get_fd_bloc_sockaddr(bloc_addr_del)); // On ferme la socket client
        set_next_bloc( bloc_addr, get_next_bloc(get_next_bloc(bloc_addr)) );
        //bloc_addr->next = & (*(get_next_bloc(get_next_bloc(bloc_addr))));
        free(bloc_addr_del);
    }
    else {
        /* Suppression d'un bloc en fin de liste */
        struct bloc_sockaddr* bloc_addr_del =get_next_bloc(bloc_addr);
        close(get_fd_bloc_sockaddr(bloc_addr_del)); // On ferme la socket client
        set_next_bloc( bloc_addr, NULL );
        //bloc_addr->next = NULL;
        free(bloc_addr_del);
    }   
}

void delete_list(struct list_bloc *list) {
    struct bloc_sockaddr *bloc_addr = list->first;
    while (get_next_bloc(get_next_bloc(bloc_addr)) != NULL) {
        /* Suppression des blocs en milieu de liste */
        struct bloc_sockaddr* bloc_addr_del = get_next_bloc(bloc_addr);
        close(get_fd_bloc_sockaddr(bloc_addr_del)); // On ferme la socket client
        set_next_bloc( bloc_addr, get_next_bloc(get_next_bloc(bloc_addr)) );
        //bloc_addr->next = & (*(get_next_bloc(get_next_bloc(bloc_addr))));
        free(bloc_addr_del);
    }

    /* Suppression du dernier client */
    struct bloc_sockaddr* bloc_addr_del = get_next_bloc(bloc_addr);
    close(get_fd_bloc_sockaddr(bloc_addr_del)); // On ferme la socket client
    set_next_bloc( bloc_addr, NULL );
    //bloc_addr->next = NULL;
    free(bloc_addr_del);

    /* Suppression du premier bloc de la liste (socket serveur) */
    close(get_fd_bloc_sockaddr(bloc_addr)); // On ferme la socket serveur
    free(bloc_addr);

    /* Suppression de la liste */
    free(list);
}