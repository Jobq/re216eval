#ifndef SERVER_FUNCTIONS_H_
#define SERVER_FUNCTIONS_H_


#define BUFLEN 1024
#define MAXCLIENTS 25

int freenick(struct list_bloc* list, char *new_nick);

int is_channel(struct list_bloc* list, char *channel);

void delete_channel(struct list_bloc* list, char* channel);

int is_channel_in_list(struct list_bloc* list, char *channel);

void add_channel(struct list_bloc* list, char* channel);

char *fill_type_server (struct list_bloc *list, struct bloc_sockaddr *current_bloc, struct message *msg_struct, char* answer, char* buffer);

void fill_pollfd(struct pollfd *pollfds, int nfds, int client_sockfd);

void send_structure(int fd, struct message *msg_struct);


void send_buffer(int fd, char* buffer);

void send_to_client(int fd, char *answer, struct bloc_sockaddr *current_bloc);


void supprimer_client(struct list_bloc *list, int client_fd);





#endif /* SERVER_FUNCTIONS_H_ */
