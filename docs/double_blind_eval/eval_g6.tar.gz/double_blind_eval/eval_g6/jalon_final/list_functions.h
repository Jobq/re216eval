#ifndef LIST_FUNCTIONS_H_
#define LIST_FUNCTIONS_H_

struct list_bloc {
    struct bloc_sockaddr *first;
    int nb_blocs; /* Correspond au nombre de sockets côté clients (sockets clients + socket d'établissement de connexion) */
    char channel_list[MAXCLIENTS][CHANNEL_LEN];
};

struct bloc_sockaddr* get_list_bloc(struct list_bloc* list);


int get_list_nb_blocs(struct list_bloc* list);
void inc_list_nb_bloc(struct list_bloc* list);
void dec_list_nb_bloc(struct list_bloc* list);

void print_list_bloc(struct list_bloc* list);

void delete_bloc_list(struct bloc_sockaddr *bloc_addr);

void delete_list(struct list_bloc *list) ;



#endif /* LIST_FUNCTIONS_H_ */
