#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <poll.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <time.h>
#include <ctype.h>

#include "common.h"
#include "msg_struct.h"

#define SIZE 200
#define USERS 30 //nombre max de users par salon

struct sockaddr_in cliaddr;
 //Creating linked list
typedef struct client_info client_info;
typedef struct List List;
typedef struct Salon salon;
typedef struct Listsalon Listsalon;


struct List {
	client_info *head;
};
struct client_info {
	int fd;
	int send_port;
	unsigned short port;
	char time[MSG_LEN];
	char nick_name[NICK_LEN];
	char salon[MSG_LEN];
	struct in_addr addr_ip;
	struct sockaddr_in *adress;
	struct client_info *next;
};
struct Salon {
	char name[MSG_LEN];
	int fds; // fd du client qui a crée le salon
	struct Salon *next;
};
struct Listsalon {
	salon *head;
};

void remove_client(int sockfd, List *list);
int stock_infos(int sockfd, List *list,struct sockaddr_in* cliaddr, int act_port);
void connected_client(List* list, int sockfd);
void whois(List* list, char * nickname, int sockfd);
int nick_exist(List *list, char* nickname);
void broadcast(List *list, char* message, int sockfd, char* nickname);
void unicast(List *list, char* nicksrc, char* nickdest, char *chat);

struct client_info * myclient(struct List * list, int sockfd);

List *init();


int handle_bind(char* port) {
	struct addrinfo hints, *result, *rp;
	int sfd;
	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;
	if (getaddrinfo(NULL, port, &hints, &result) != 0) {
		perror("getaddrinfo()");
		exit(EXIT_FAILURE);
	}
	for (rp = result; rp != NULL; rp = rp->ai_next) {
		sfd = socket(rp->ai_family, rp->ai_socktype,rp->ai_protocol);
		if (sfd == -1) {
			continue;
		}
		if (bind(sfd, rp->ai_addr, rp->ai_addrlen) == 0) {
			break;
		}
		close(sfd);
	}
	if (rp == NULL) {
		fprintf(stderr, "Could not bind\n");
		exit(EXIT_FAILURE);
	}
	freeaddrinfo(result);
	return sfd;
}
List *init() //initialiser la liste chainée
{
	List *list = malloc(sizeof(list));
	client_info *client_info = malloc(sizeof(client_info));

    if (list == NULL || client_info == NULL)
    {
        exit(EXIT_FAILURE);
    }
	client_info->fd = 0;
	client_info->port = 0;
	client_info->send_port = 0;
	strcpy(client_info->nick_name, "\0");
	strcpy(client_info->salon, "\0");
	client_info->adress = NULL;
    client_info->next = NULL;
    list->head = client_info;

    return list;

}
Listsalon *initialiser()
{
	Listsalon *listsalon = malloc(sizeof(listsalon));
	salon *salon = malloc(sizeof(salon));
	if (listsalon == NULL || salon == NULL)
    {
        exit(EXIT_FAILURE);
    }
	salon->fds = 0;
	salon->next = NULL;
	listsalon->head = salon;

	return listsalon;

}
void addsalon(Listsalon *listsalon, char *title, int fds)
{
	salon *new_salon = malloc(sizeof(*new_salon));
	if (listsalon == NULL || new_salon == NULL)
    {
        exit(EXIT_FAILURE);
    }
	strcpy(new_salon->name ,title);
	new_salon->fds = fds;
	new_salon->next = listsalon->head;
	listsalon->head = new_salon;

}
void joinsalon(List *list, char* title, int sockfd)
{
	client_info *tmp = list->head;
	if (list == NULL)
    	{
        	exit(EXIT_FAILURE);
    	}
	while (tmp != NULL)
	{
		if (tmp->fd == sockfd)
		{
			strcpy(tmp->salon, title);
			return;
		}
	tmp =tmp->next;
	}
	return;
}
int nick_exist(List *list, char* nickname)
{
	if (list == NULL)
    {
        exit(EXIT_FAILURE);
    }
	if (strcmp(nickname,"")==0)
	{
		return 0;
	}
	client_info *tmp = list->head;
	while(tmp != NULL)
	{
		if (strcmp(tmp->nick_name,nickname)==0)
		{
			return 1;
			exit(EXIT_SUCCESS);
		}
		tmp = tmp->next;
	}
	return 0;
}
int salon_exist(Listsalon *listsalon, char *title)  //verifie si un salon existe
{
	if (listsalon == NULL)
    {
        exit(EXIT_FAILURE);
    }
	if (strcmp(title,"")==0)
	{
		return 0;
	}
	salon *tmp = listsalon->head;
	while(tmp != NULL)
	{
		if (strcmp(tmp->name, title)==0)
		{
			return 1;
			exit(EXIT_SUCCESS);
		}
		tmp = tmp->next;
	}
	return 0;
}
int salon_empty(List *list, char* channel)
{
	client_info *tmp = list->head;
	if (list == NULL )
 	 {
   		 exit(EXIT_FAILURE);
 	 }
	while(tmp != NULL)
	{
		if (strcmp(tmp->salon, channel)==0)
		{
			return 1;
		}
		tmp = tmp->next;
	}
	return 0;
}
void list_salon(int sockfd,Listsalon *listsalon)
{
    if (listsalon == NULL)
    {
        exit(EXIT_FAILURE);
    }
    salon *tmp = listsalon->head;
    char msg4[MSG_LEN];
		memset(msg4, 0, MSG_LEN);
		strcpy(msg4,"[Server] : Available channel :  \n");
    while (tmp != NULL) //tout sauf le server
    {
		if (strcmp(tmp->name,"")==0)
		{
			tmp = tmp->next;
		}
		else
		{
		char msg[MSG_LEN] = " - ";
    strcat(msg, tmp->name);
    strcat(msg, "\n");
		strcat(msg4, msg);
		tmp = tmp->next;
		}
    }
	send(sockfd, msg4, MSG_LEN, 0);
	memset(msg4,0,MSG_LEN);
	return ;
}
int stock_infos(int sockfd, List *list,struct sockaddr_in* cliaddr, int act_port)
{
	client_info *new_client = malloc(sizeof(*new_client));
	new_client->fd = sockfd;
	new_client->port = cliaddr->sin_port;
	new_client->send_port = act_port+1;
	new_client->adress = cliaddr;
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	sprintf(new_client->time,"%d-%d-%d %d:%d:%d\n", tm.tm_year + 1900, tm.tm_mon + 1,tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
	new_client->addr_ip = cliaddr->sin_addr;
	new_client->port = cliaddr->sin_port;
	new_client->next = list->head;
	list->head = new_client;
	act_port += 1;
	return act_port;
}
void stock_nick_infos(List* list, int sockfd, char* nickname)
{
	client_info *tmp = list->head;
	if (list == NULL )
  {
    exit(EXIT_FAILURE);
  }
	while(tmp->next != NULL)
	{
		if(tmp->fd == sockfd)
		{
			strcpy(tmp->nick_name, nickname);
			return;
		}
	}
	return;

}
struct client_info * myclient(struct List * list, int sockfd){
  struct client_info *tmp = list->head;
  if (list == NULL )
  {
    exit(EXIT_FAILURE);
  }
  while(tmp->next!= NULL){
    if(tmp->fd == sockfd)
    {
      return tmp;
    }
    tmp = tmp->next;
  }
  return NULL;
}
struct Salon *mychannel(struct Listsalon *listsalon, char* channel){
  salon *tmp = malloc(sizeof(*tmp));
	tmp = listsalon->head;
  if (listsalon == NULL )
  {
    exit(EXIT_FAILURE);
  }
  while(tmp->next != NULL){
    if(strcmp(tmp->name,channel)==0)
    {
      return tmp;
    }
    tmp = tmp->next;
  }
  return NULL;
}
void remove_client(int sockfd, List *list)
{
	client_info *tmp = malloc(sizeof(*tmp));
	tmp = list->head;
	if (list == NULL)
    {
        exit(EXIT_FAILURE);
    }
	while(tmp->next != NULL)
	{
		if(tmp->fd == sockfd)
		{
        	list->head = tmp->next;
        	free(tmp);
			memset(tmp->nick_name, 0, NICK_LEN);
			memset(tmp->salon, 0, MSG_LEN);
			return;
		}
		client_info *suiv = tmp->next;
		if(suiv->fd == sockfd)
		{
			tmp->next = suiv->next;
			free(suiv);
			memset(suiv->nick_name, 0, NICK_LEN);
			memset(suiv->salon, 0, MSG_LEN);
			return;
		}
		tmp = tmp->next;
	}
    return;
}

void remove_salon(Listsalon *listsalon, char* channel)
{
	salon *tmp = listsalon->head;
	if (listsalon == NULL)
	{
		exit(EXIT_FAILURE);
	}
	while(tmp->next != NULL)
	{
		if(strcmp(tmp->name, channel)==0)
		{
			listsalon->head = tmp->next;
			free(tmp);
			return;
		}
		salon *suiv = tmp->next;
		if(strcmp(suiv->name, channel)==0)
		{
			tmp->next = suiv->next;
			free(suiv);
			return;
		}
		tmp = tmp->next;
	}
}
void connected_client(List* list, int sockfd)
{
    if (list == NULL)
    {
        exit(EXIT_FAILURE);
    }
    client_info *tmp = list->head;
    char msg4[MSG_LEN] = "[Server] : Online users are :  \n";
    while (tmp != NULL && (tmp->fd != 3)) //tout sauf le server
    {
        if(tmp->nick_name == NULL || tmp->fd == sockfd ){ //ne pas afficher le client qui a lancé la commande ou un client sans nickname
            tmp = tmp->next;
        }
		else if (strcmp(tmp->nick_name,"")==0)
		{
			tmp = tmp->next;
		}
		else
		{
		char msg[MSG_LEN] = " - ";
        strcat(msg, tmp->nick_name);
        strcat(msg, "\n");
		strcat(msg4, msg);
		tmp = tmp->next;
		}
    }

    send(sockfd,msg4,MSG_LEN,0);
	memset(msg4,0,MSG_LEN);
}
void whois(List* list, char * nickname, int sockfd)
{
 	if (list == NULL)
   		 {
        	exit(EXIT_FAILURE);
    	}
	char msg[MSG_LEN] = " connected since ";
	char wi[MSG_LEN] = " with IP address ";
	char wie[MSG_LEN] = " with Port address ";
	client_info *tmp = list->head;
	while (tmp != NULL )
	{
		if (tmp->nick_name != NULL)
		{
		  if(strcmp(tmp->nick_name,nickname)==0)
		  {
			strcat(nickname, msg);
			strcat(nickname, tmp->time);
			strcat(nickname,wi);
			strcat(nickname, inet_ntoa(tmp->addr_ip));
			strcat(nickname,wie);
			char ports[MSG_LEN];
			sprintf(ports, "%d", tmp->port);
			strcat(nickname, ports);
		   }

		}
		tmp = tmp->next;
	}

send(sockfd, nickname,MSG_LEN, 0);

}
void broadcast(List *list, char* message, int sockfd, char* nickname)
{
	if (list == NULL)
    	{
        	exit(EXIT_FAILURE);
    	}
	client_info *tmp = list->head;
	while(tmp != NULL )
	{
		if(tmp->fd != sockfd)
		{
			char msg[MSG_LEN] = "[ ";
			strcat(msg, nickname);
			strcat(msg, " ] : ");
			strcat(msg, message);
			send(tmp->fd, msg, MSG_LEN, 0);
			memset(msg,0,MSG_LEN);
		}
		tmp = tmp->next;
	}
}
void unicast(List *list, char* nicksrc, char* nickdest, char *chat)
{
	if (list == NULL)
    {
        exit(EXIT_FAILURE);
    }
	client_info *tmp = list->head;
	while(tmp != NULL)
	{
		if (strcmp(tmp->nick_name, nickdest)==0)
		{
			char msg[MSG_LEN] = "[ ";
			strcat(msg, nicksrc);
			strcat(msg, " ] : ");
			strcat(msg, chat);
			send(tmp->fd,msg,MSG_LEN,0);
		}
		tmp = tmp->next;
	}

}
void file_send_request(List *list, char* nicksrc, char* nickdest, char *filename)
{
	if (list == NULL)
    {
        exit(EXIT_FAILURE);
    }
	int port_send;
	client_info *act = list->head;
	while(act != NULL)
	{
		if (strcmp(act->nick_name, nicksrc)==0)
		{
			port_send = act->send_port;
		}
		act = act->next;
	}
	client_info *tmp = list->head;
	while(tmp != NULL)
	{
		if (strcmp(tmp->nick_name, nickdest)==0)
		{
			char msg[MSG_LEN] = " ";
			strcat(msg,"[send_request§] ");
			char sendp[10]= " ";
			sprintf(sendp, "%d ", port_send);
			strcat(msg, sendp);
			strcat(msg, nicksrc);
			strcat(msg, " wants you to accept the transfer of the file named : ");
			strcat(msg, filename);
			strcat(msg, ". Do you accept? [Y/N]");
			send(tmp->fd,msg,MSG_LEN,0);
		}
		tmp = tmp->next;
	}

}
void file_send_ack(List *list, char* nicksrc, char* nickdest, char *filename)
{
	if (list == NULL)
    {
        exit(EXIT_FAILURE);
    }
	client_info *tmp = list->head;
	while(tmp != NULL)
	{
		if (strcmp(tmp->nick_name, nickdest)==0)
		{
			char msg[MSG_LEN] = " ";
			strcat(msg, nicksrc);
			strcat(msg, " received ");
			strcat(msg, filename);
			strcat(msg, "successfully!");
			send(tmp->fd,msg,MSG_LEN,0);
		}
		tmp = tmp->next;
	}

}
void file_send_request_accepted(List *list, char* nicksrc, char* nickdest)
{
	if (list == NULL)
    {
        exit(EXIT_FAILURE);
    }
	client_info *tmp = list->head;
	while(tmp != NULL)
	{
		if (strcmp(tmp->nick_name, nickdest)==0)
		{
			char msg[MSG_LEN] = " ";
			strcat(msg,"[send_accept¤] ");
			strcat(msg, nicksrc);
			strcat(msg, " ");
			strcat(msg, inet_ntoa(tmp->addr_ip));
			char ports[MSG_LEN];
			sprintf(ports, " %d", tmp->send_port);
			strcat(msg,ports);
			strcat(msg, " accepted file transfert.");
			send(tmp->fd,msg,MSG_LEN,0);
		}
		tmp = tmp->next;
	}

}
void file_send_request_refused(List *list, char* nicksrc, char* nickdest)
{
	if (list == NULL)
    {
        exit(EXIT_FAILURE);
    }
	client_info *tmp = list->head;
	while(tmp != NULL)
	{
		if (strcmp(tmp->nick_name, nickdest)==0)
		{
			char msg[MSG_LEN] = " ";
			strcat(msg, nicksrc);
			strcat(msg, " cancelled file transfer.");
			send(tmp->fd,msg,MSG_LEN,0);
		}
		tmp = tmp->next;
	}

}
void multicast(List* list, char* channel, char* mltcstmsg, int fds)
{
	if (list == NULL)
    {
        exit(EXIT_FAILURE);
    }
	client_info *tmp = list->head;
	while(tmp != NULL)
	{
		if (strcmp(tmp->salon, channel)==0 && tmp->fd != fds )
		{

			send(tmp->fd, mltcstmsg, MSG_LEN, 0);
		}
		tmp = tmp->next;

	}

}



void poll_server(int sfd, client_info *client){
	int  timeout = -1;
	struct sockaddr_in cliaddr;
	socklen_t len = sizeof(cliaddr);
	struct pollfd fds[SIZE];
	memset(fds, 0 , sizeof(fds));
	fds[0].fd = sfd;
    fds[0].events = POLLIN;
	int nfds = 1;
	int res, cpt=0, i;
	int new_conn=-1;
	int end=0;
	int act_port = 8080;
    struct message msgstruct;
	List *mylist = init();
	Listsalon *mysalon = initialiser();
	do
	{
		res = poll(fds, SIZE, timeout);
		if(res < 0){
		 	perror("poll error");
		break;
		}
		else
		{
			cpt = nfds;
			for(i = 0; i < cpt; i++)
			{
				if(fds[i].revents == 0)
        			continue;
				if(fds[i].revents != POLLIN)
      			{
        			printf("  Error! revents = %d\n", fds[i].revents);
					end = 1;
        			break;
				}
				if(fds[i].fd == sfd )
				{   //non-blocking mode for listening socket
					int flags = fcntl(fds[i].fd, F_GETFL);
					fcntl(fds[i].fd, F_SETFL, flags | O_NONBLOCK);
					printf("Listening socket...\n");
					do
					{	int flags = fcntl(fds[i].fd, F_GETFL);
						fcntl(fds[i].fd, F_SETFL, flags | O_NONBLOCK);
						new_conn = accept(sfd,(struct sockaddr*)&cliaddr, &len);
          				if (new_conn < 0)
         				 {
            				if (errno != EWOULDBLOCK)
            				{
              					perror("  accept() failed");
              					break;
           				     }
           					break;
          				}

          				printf("  New incoming connection - %d\n", new_conn);

          				fds[nfds].fd = new_conn;
          				fds[nfds].events = POLLIN;
						act_port=stock_infos(fds[nfds].fd, mylist, &cliaddr,act_port);
          				nfds++;
					} while (new_conn != -1);


				}
				else

				{
					int flags = fcntl(fds[i].fd, F_GETFL); // non-blocking mode for other sockets
					fcntl(fds[i].fd, F_SETFL, flags | O_NONBLOCK);
					do
					{
						while (1) {
                    // Cleaning memory
                    memset(&msgstruct, 0, sizeof(struct message));

                    // Receiving structure
                    if (recv(fds[i].fd, &msgstruct, sizeof(struct message), 0) <= 0) {
                        break;
                    }
					if (msgstruct.type == 10) //quit channel
					{
						struct client_info *actual_client = myclient(mylist,fds[i].fd);
						struct Salon * actual_salon = mychannel(mysalon,msgstruct.infos );

						//printf("je suis la %d",strcmp(msgstruct.infos, "/quit"));
						if(strcmp(msgstruct.infos, "/quit")<0 ){
                        printf("%s has left the chat \n", msgstruct.nick_sender);
                        remove_client(fds[i].fd, mylist);
                        close(fds[i].fd);
                        fds[i].fd=-1;
                        fds[i].events =-1;
                        fds[i].revents = -1;
                   		 }
						else if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warne[MSG_LEN];
							 memset(warne,0,MSG_LEN);
							 strcpy(warne,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warne,MSG_LEN,0);
						 }
						else{
							if(salon_exist(mysalon,msgstruct.infos)==0){
								char coms[MSG_LEN];
								memset(coms, 0, MSG_LEN);
								strcpy(coms, " This channel doesn't exist\n");
								send(fds[i].fd, coms, MSG_LEN, 0);
							}
							if (strcmp(actual_client->salon, msgstruct.infos)!=0 && salon_exist(mysalon,msgstruct.infos)!=0)
								{
									char coms[MSG_LEN];
									memset(coms, 0, MSG_LEN);
									strcpy(coms, " You are not member of this channel!\n");
									send(fds[i].fd, coms, MSG_LEN, 0);
								}

							else
							{
								char comsi[MSG_LEN];
								memset(comsi, 0, MSG_LEN);
								strcpy(comsi, " You quit a channel!\n");
								send(fds[i].fd, comsi, MSG_LEN, 0);
								strcpy(actual_client->salon,"");
								if (salon_empty(mylist,msgstruct.infos)==0)
								{
									remove_salon(mysalon, msgstruct.infos);
									char rem[MSG_LEN];
									memset(rem, 0, MSG_LEN);
									strcpy(rem,msgstruct.infos);
									strcat(rem, " has been destroyed");
									send(actual_salon->fds, rem, MSG_LEN, 0);
								}

							}

						 }


					}


                 	if (msgstruct.type==1) { //who
					 	if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
						 }

						else{
						connected_client(mylist,  fds[i].fd);
						}

                    }
                    else if (msgstruct.type==0){

                        struct client_info *actual_client = (struct client_info*) malloc(sizeof(struct client_info));
						actual_client = myclient(mylist,fds[i].fd);

                        if((actual_client != NULL) && (strlen(msgstruct.infos)) != 0){

                        if (strcmp(actual_client->nick_name, "\0")!=0){
                            char msg2[MSG_LEN];
							memset(msg2,0,MSG_LEN);
                            sprintf(msg2,"[Server] : Your new nickname is ");
                            strcat(msg2, msgstruct.infos);
                            send(fds[i].fd, msg2, MSG_LEN, 0);

                        }
						else
                        {
                            //if(isspace msgstruct.infos)
                            if(nick_exist(mylist,msgstruct.infos)==0)
                            {
                            char msg2[MSG_LEN];
							memset(msg2,0,MSG_LEN);
                            sprintf(msg2,"[Server] : Welcome on chat ");
                            strcat(msg2, msgstruct.infos);
                            send(fds[i].fd, msg2, sizeof(msg2), 0);
                            }
                            else
                            {
                                char msg5[MSG_LEN];
                                sprintf(msg5,"[Server] : Nickname already exists");
                                send(fds[i].fd, msg5, sizeof(msg5), 0);
								memset(msg5,0,MSG_LEN);
                            }

                        }

                        }
						char nickname[MSG_LEN];
						memset(nickname,0,MSG_LEN);
						strcpy(nickname,msgstruct.infos);
                        stock_nick_infos(mylist, fds[i].fd, nickname);

                    }
                    else if (msgstruct.type==2)
                    {
						if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
						 }
						else{
							if(nick_exist(mylist, msgstruct.infos)==1){
								whois(mylist, msgstruct.infos, fds[i].fd);
							}
							else
							{
								char msg[MSG_LEN];
								memset(msg,0,MSG_LEN);
								strcpy(msg, "[Server] : User doesn't exist\n");
								send(fds[i].fd, msg, MSG_LEN, 0);

							}
						}

                    }
                    else if (msgstruct.type == 5) //broadcast
                    {
						if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
						 }
						else {
							broadcast(mylist,msgstruct.infos,fds[i].fd, msgstruct.nick_sender);
						}
                    }
                    else if (msgstruct.type == 4) //unicast
                    {
                       if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
						 }
					    else {
							if(nick_exist(mylist, msgstruct.infos)==1){
                            char buff_unicast[MSG_LEN];
							memset(buff_unicast,0,MSG_LEN);
                            recv(fds[i].fd,buff_unicast,MSG_LEN,0);
                            unicast(mylist, msgstruct.nick_sender, msgstruct.infos, buff_unicast);
							}
							else
							{
								char msg[MSG_LEN];
								memset(msg,0,MSG_LEN);
								strcpy(msg, " doesn't exist\n");
								strcat(msgstruct.infos, msg);
								send(fds[i].fd, msgstruct.infos, MSG_LEN, 0);

							}
						}
                    }
					else if (msgstruct.type == 11) //send_file
                    {
                       if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
						 }
					    else {
							if(nick_exist(mylist, msgstruct.infos)==1){
                            char file_name[MSG_LEN];
							memset(file_name,0,MSG_LEN);
                            recv(fds[i].fd,file_name,MSG_LEN,0);
                            file_send_request(mylist, msgstruct.nick_sender, msgstruct.infos, file_name);
							}
							else
							{
								char msg[MSG_LEN];
								memset(msg,0,MSG_LEN);
								strcpy(msg, " doesn't exist\n");
								strcat(msgstruct.infos, msg);
								send(fds[i].fd, msgstruct.infos, MSG_LEN, 0);

							}
						}
                    }
					else if (msgstruct.type == 16) //send_file_ack
                    {
                       if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
						 }
					    else {
							if(nick_exist(mylist, msgstruct.infos)==1){
								char file_name[MSG_LEN];
								memset(file_name,0,MSG_LEN);
								recv(fds[i].fd,file_name,MSG_LEN,0);
								file_send_ack(mylist, msgstruct.nick_sender, msgstruct.infos, file_name);
							}
							else
							{
								char msg[MSG_LEN];
								memset(msg,0,MSG_LEN);
								strcpy(msg, " doesn't exist\n");
								strcat(msgstruct.infos, msg);
								send(fds[i].fd, msgstruct.infos, MSG_LEN, 0);

							}
						}
                    }
					else if (msgstruct.type == 12) //request_accepted
                    {
                       if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
						 }
					    else {
							if(nick_exist(mylist, msgstruct.infos)==1){
                            file_send_request_accepted(mylist, msgstruct.nick_sender, msgstruct.infos);
							}
							else
							{
								char msg[MSG_LEN];
								memset(msg,0,MSG_LEN);
								strcpy(msg, " doesn't exist\n");
								strcat(msgstruct.infos, msg);
								send(fds[i].fd, msgstruct.infos, MSG_LEN, 0);

							}
						}
                    }

					else if (msgstruct.type == 13) //request_refused
                    {
                       if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
						 }
					    else {
							if(nick_exist(mylist, msgstruct.infos)==1){
                            file_send_request_refused(mylist, msgstruct.nick_sender, msgstruct.infos);
							}
							else
							{
								char msg[MSG_LEN];
								memset(msg,0,MSG_LEN);
								strcpy(msg, " doesn't exist\n");
								strcat(msgstruct.infos, msg);
								send(fds[i].fd, msgstruct.infos, MSG_LEN, 0);

							}
						}
                    }
                    else if (msgstruct.type == 3) //echo_send
                    {
                    	struct client_info *actual_client = myclient(mylist,fds[i].fd);
					    if(strcmp(actual_client->salon,"")==0)
						{
							char rcv[MSG_LEN];
							memset(rcv,0,MSG_LEN);
							strcpy(rcv,msgstruct.infos);
							send(fds[i].fd, rcv,MSG_LEN,0);
						}
						else if(strcmp(actual_client->salon,"")!=0)
						{
							if(strcmp(msgstruct.nick_sender,"")==0)
							 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
							 }
							 else{
								/*if (strcmp(actual_client->salon, msgstruct.infos) !=0 )
								{
									char com[MSG_LEN];
									memset(com, 0, MSG_LEN);
									strcpy(com, "[Server] : You are not member of this channel\n");
									send(fds[i].fd, com, MSG_LEN, 0);
								}*/
								//else
								//{

									//recv(fds[i].fd,buff_multicast,MSG_LEN,0);
									char buff_multicast[MSG_LEN];
									memset(buff_multicast,0,MSG_LEN);
									strcpy(buff_multicast,msgstruct.nick_sender);
									strcat( buff_multicast," : > ");
									strcat( buff_multicast,msgstruct.infos);
									multicast(mylist,actual_client->salon, buff_multicast, fds[i].fd );

								//}
						 }

						}

                    }
					else if (msgstruct.type == 6) //create channel
					{
						struct client_info *actual_client = (struct client_info*) malloc(sizeof(struct client_info));
						actual_client = myclient(mylist,fds[i].fd);
						if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
						 }
						else {
							if (salon_exist(mysalon,msgstruct.infos)==1){
							char com[MSG_LEN];
							memset(com, 0, MSG_LEN);
							strcpy(com, " already exists, choose another name\n");
							strcat(msgstruct.infos, com);
							send(fds[i].fd, msgstruct.infos, MSG_LEN, 0);
							}
							else if (strcmp(actual_client->salon, "\0")!=0)
							{
								printf("mon salon est %s\n",actual_client->salon);
								char com[MSG_LEN];
								memset(com, 0, MSG_LEN);
								strcpy(com, " [Server] : You have already created a channel!\n");
								send(fds[i].fd, com, MSG_LEN, 0);
							}
							else{
							printf("A channel is created \n");
							char com[MSG_LEN];
							memset(com, 0, MSG_LEN);
							strcpy(com, " You have  created channel ");
							strcat (com,msgstruct.infos );
							strcat(com, " \n");
							send(fds[i].fd, com, MSG_LEN, 0);
							addsalon(mysalon, msgstruct.infos, fds[i].fd);
							joinsalon(mylist,msgstruct.infos, fds[i].fd );

						}
						}
					}
					else if (msgstruct.type == 7) //channel_list
                    {
						if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
						 }
						 else{
						list_salon(fds[i].fd,mysalon);
						 }
                    }
					else if (msgstruct.type == 8) //join channel
					{
						struct client_info *actual_client = myclient(mylist,fds[i].fd);
						if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
						 }
						else{
							if(salon_exist(mysalon,msgstruct.infos)==0){
								char come[MSG_LEN];
								memset(come, 0, MSG_LEN);
								strcpy(come, " This channel doesn't exist\n");
								send(fds[i].fd, come, MSG_LEN, 0);
							}
							else if (strcmp(actual_client->salon, "")!=0)
							{
								if (strcmp(actual_client->salon, msgstruct.infos)!=0)
								{
									char come[MSG_LEN];
									memset(come, 0, MSG_LEN);
									strcpy(come, " You have already joined a channel!\n");
									send(fds[i].fd, come, MSG_LEN, 0);
								}
								else if (strcmp(actual_client->salon, msgstruct.infos)==0)
								{
									char come[MSG_LEN];
									memset(come, 0, MSG_LEN);
									strcpy(come, " You are already in this channel!\n");
									send(fds[i].fd, come, MSG_LEN, 0);
								}
							}

							else{
								joinsalon(mylist, msgstruct.infos, fds[i].fd);
								char come[MSG_LEN];
								memset(come, 0, MSG_LEN);
								strcpy(come, " You have joined ");
								strcat(come , msgstruct.infos);
								strcat(come, "\n");
								send(fds[i].fd, come, MSG_LEN, 0);

						}

						}

					}

					/*else if (msgstruct.type == 9) //multicast send
					{
						struct client_info *actual_client = myclient(mylist,fds[i].fd);
						if(strcmp(msgstruct.nick_sender,"")==0)
						 {
							 char warn[MSG_LEN];
							 memset(warn,0,MSG_LEN);
							 strcpy(warn,"[SERVER] : Please login with /nick <your pseudo>\n");
							 send(fds[i].fd,warn,MSG_LEN,0);
						 }
						 else{
							if (strcmp(actual_client->salon, msgstruct.infos) !=0 )
							{
								char com[MSG_LEN];
								memset(com, 0, MSG_LEN);
								strcpy(com, "[Server] : You are not member of this channel\n");
								send(fds[i].fd, com, MSG_LEN, 0);
							}
							else
							{
								char buff_multicast[MSG_LEN];
								memset(buff_multicast,0,MSG_LEN);
								recv(fds[i].fd,buff_multicast,MSG_LEN,0);
								multicast(mylist,msgstruct.infos, buff_multicast);

							}
						 }

					}*/



                }

                break;

                }while(1);


                            }
                        }
                        }

		}while (end == 0);
int j;
	for (j= 0; j < nfds; j++)
  		{
    		if(fds[j].fd >= 0)
      		close(fds[j].fd);
 		 }

}


int main(int argc, char* argv[]) {
	if (argc < 2) {
		fprintf(stderr, "Usage: %s port \n", argv[0]);
		exit(EXIT_FAILURE);
	}

	int sfd, listen_fd;
	sfd = handle_bind(argv[1]);
	listen_fd = (listen(sfd, SOMAXCONN));
	if (listen_fd != 0) {
		perror("listen()\n");
		exit(EXIT_FAILURE);
	}

	client_info *client = malloc(sizeof(client_info));

	poll_server(sfd, client);
	close(sfd);
	return EXIT_SUCCESS;
}
