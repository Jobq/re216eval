Dernier jalon réalisé : Jalon 4

Pour quiter un salon il faut utiliser la syntaxe précisée sur le répo git:
    /quit salon
    et non pas /quit seul.

/send marche corréctement sur les machines perso
