#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <poll.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <ctype.h>

#include "common.h"
#include "msg_struct.h"
#define SIZE 4


int handle_connect(char* ip, char* port) {
    struct addrinfo hints;
    struct addrinfo *result, *rp;
	int sfd;
	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = 0;
    hints.ai_protocol = 0;
	if (getaddrinfo(ip, port, &hints, &result) != 0) {
		perror("getaddrinfo()");
		exit(EXIT_FAILURE);
	}
	for (rp = result; rp != NULL; rp = rp->ai_next) {
		sfd = socket(rp->ai_family, rp->ai_socktype,rp->ai_protocol);
		if (sfd == -1) {

			continue;
		}
		if (connect(sfd, rp->ai_addr, rp->ai_addrlen) != -1) {

			break;
		}
		close(sfd);
	}
	if (rp == NULL) {
		fprintf(stderr, "Could not connect\n");
		exit(EXIT_FAILURE);
	}
	freeaddrinfo(result);
	return sfd;
}

int handle_bind(char* ip, char* port) {
	struct addrinfo hints, *result, *rp;
	int sfd;
	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;
	if (getaddrinfo(ip, port, &hints, &result) != 0) {
		perror("getaddrinfo()");
		exit(EXIT_FAILURE);
	}
	for (rp = result; rp != NULL; rp = rp->ai_next) {
		sfd = socket(rp->ai_family, rp->ai_socktype,rp->ai_protocol);
		if (sfd == -1) {
			continue;
		}
		if (bind(sfd, rp->ai_addr, rp->ai_addrlen) == 0) {
			break;
		}
		close(sfd);
	}
	if (rp == NULL) {
		fprintf(stderr, "Could not bind\n");
		exit(EXIT_FAILURE);
	}
	freeaddrinfo(result);
	return sfd;
}

void poll_client(int sfd){

	struct sockaddr_in cliaddr;
	socklen_t len = sizeof(cliaddr);
	char buff[MSG_LEN];
	char buff_nick[NICK_LEN];
	char * file_send_src = (char *)malloc(sizeof(char)*MSG_LEN);
	memset(file_send_src, 0, sizeof(char)*MSG_LEN);
	char * file_name = (char *)malloc(sizeof(char)*MSG_LEN);
	memset(file_name, 0, sizeof(char)*MSG_LEN);
	char commande[10];
	char message[MSG_LEN];
	char * nickname = (char *)malloc(sizeof(char)*MSG_LEN);
	memset(nickname, 0, sizeof(char)*MSG_LEN);
	char msg[MSG_LEN];
	int  timeout = -1;
	struct pollfd * fds = malloc(4*sizeof(struct pollfd)) ;
	char * my_send_port = (char *)malloc(sizeof(char)*20);
	memset(my_send_port, 0, sizeof(char)*20);
	char * config = (char *)malloc(sizeof(char)*30);
	memset(config, 0, sizeof(char)*30);
	fds[0].fd = 0;
    fds[0].events = POLLIN;
	fds[0].revents = 0;
	fds[1].fd = sfd;
    fds[1].events = POLLIN;
	fds[1].revents = 0;
    int  res, i, file_src, send_sfd;
	int request;
	int new_conn=-1;
	int status_send = 0;
	int status_recv = 0;
	int status_op = 0;
	int recv_sfd,listen_fd;
	char * target_ip = (char *)malloc(sizeof(char)*20);
	memset(target_ip, 0, sizeof(char)*20);
	char * target_port = (char *)malloc(sizeof(char)*20);
	memset(target_port, 0, sizeof(char)*20);
	strcpy(message,"1");
	memset(buff_nick, 0, NICK_LEN);

	while(1)
	{
		if (status_send == 1)
		{
			send_sfd = handle_connect(target_ip,target_port);
		/*	fds[2].fd = send_sfd;
			fds[2].events = POLLIN;
			fds[2].revents = 0;	 */
			memset(message, 0,MSG_LEN);
			strcat(message,file_name);
			if (send(send_sfd, message, MSG_LEN, 0) <= 0) {
				exit(EXIT_FAILURE);
			}
			printf("filename sent: %s\n",message);
			if ((file_src = open(file_name,O_RDONLY)) == -1) {
				printf("Une erreur est survenue!\n");
			}else{
			/*Recupere la taille du fichier*/
				struct stat infos;
				fstat(file_src,&infos);

				int n = 0;
				int tailleFichier = infos.st_size;
				int tailleEnvoyee = 0;
				printf("Taille totale du fichier transmis: %d \n",tailleFichier);
				/*Envoi de la taille du fichier*/
				if (send(send_sfd, &tailleFichier,sizeof(int), 0) <= 0) {
					exit(EXIT_FAILURE);
				}


				while (tailleEnvoyee < tailleFichier ) {

					/* lecture du fichier et d'ecriture dans la socket */
					memset(message, 0,MSG_LEN);
					if ((n=read(file_src,message,MSG_LEN)) < 0) {
						perror("Read");
						exit(5);
					}

					tailleEnvoyee += n;

					printf("Taille du lot transmis: %d \n",n);

					if (send(send_sfd, message,n, 0) != n) {
						printf("walu masardshi n\n");
					}
				}
				/* fermeture du fichier a lire */
				close(file_src);
			}
			// close the socket
    		close(send_sfd);
			status_send = 0;
		}
		if (status_recv == 2)
		{
			recv_sfd = handle_bind("127.0.0.1",my_send_port);
			 fds[3].fd = recv_sfd;
			 fds[3].events = POLLIN;
			listen_fd = (listen(recv_sfd, SOMAXCONN));
			if (listen_fd != 0) {
				perror("listen()\n");
				exit(EXIT_FAILURE);
			}
			int new_socket;
			if ((new_socket=accept(recv_sfd,(struct sockaddr*)&cliaddr, &len)) < 0)
			{
				printf("server acccept failed...\n");
				if (errno != EWOULDBLOCK)
				{
					perror("accept() failed");
					break;
				}
				else
				{
					printf("dikshi likayn\n");
				}

				break;
			}

			printf("En attendant la reception du fichier...\n");
			memset(file_name,0,MSG_LEN);
			recv(new_socket, file_name, MSG_LEN, 0);
			printf("message: %s\n",file_name);
			int tailleMessage = 0;
			int fic;
			int totalRecu = 0;
			int m=0;
			 if ((fic = open(file_name, O_WRONLY | O_CREAT | O_TRUNC,0666)) == -1) {
				fflush(stdout);
				perror("Erreur dans l ouverture du fichier: ");
			}else{

				/*On recupere la taille du message*/
				recv(new_socket, &tailleMessage, sizeof(int), 0);
				printf("Taille du message recu: %d\n",tailleMessage);
				fflush(stdout);

				while(totalRecu < tailleMessage ){

					/* lecture dans la socket et ecriture dans le fichier */
					if ((m=recv(new_socket, message, MSG_LEN, 0)) <= 0) {
						printf("error recv\n");
					}

					totalRecu += m;

					if (write(fic,message,m) != m){
						perror("write");
						exit(7);
					}

				}

				if(tailleMessage > totalRecu){
					printf("Message recu IMCOMPLET \n");
					fflush(stdout);
				}
				else
				{
					printf("Fichier recu avec succès ! \n");
					status_op = 1;
				}

				/* fermeture du fichier a ecrire */
				close(fic);
				}
			close(recv_sfd);
			status_recv = 0;
		}
		//printf("status_recv: %d\n",status_recv);
		res = poll(fds, SIZE, timeout);
		if(res < 0){
			perror("poll error");
			break;
		}
		else{
				if (fds[0].revents == POLLIN)
					{

					// Cleaning memory
							memset(commande, 0, MSG_LEN);
							memset(msg, 0, MSG_LEN);
							// Getting message from client
							int n = 0;
							while ((buff[n++] = getchar()) != '\n') {} // trailing '\n' will be sent
							//send_file condition
							if (request==1)
							{
								if (strcmp(buff,"Y\n")==0){
									request=2;
								}
								else if (strcmp(buff,"N\n")==0)
								{
									request=3;
								}
								else
								{
									printf("Please use only Y to accept the file or N to refuse!\n");
								}

							}

							// Filling structure
							sscanf(buff, "%s %[^\n]",commande, msg);
							struct message *msgstruct = (struct message *)malloc(sizeof(struct message));
							//memset(msgstruct, 0, sizeof(struct message));
							msgstruct->pld_len = strlen(msg);
							if (status_op == 1)
								{
									msgstruct->type = FILE_ACK;
									strcpy(msgstruct->infos, file_send_src);
									strcpy(msgstruct->nick_sender, nickname);
									status_op = 0;
								}
							 else if(strcmp(commande, "/nick")==0)
									{

									sscanf(buff, "%*5[^'0']%*c%[^\n]", buff_nick);
									int n = 0;
									for(i=0; buff_nick[i] != '\0'; i++)
									{
										if ((buff_nick[i] == ' ' && buff_nick[i+1]!='\n') || (isdigit(buff_nick[i])==0 && isalpha(buff_nick[i])==0))
										   n++;
									}
									if (n>0)
									{
										printf("Invalid pseudo! \n"); //espace ou caractère spéciaux
									}

									else if (strlen(buff_nick)>20)
									{
				 						printf("Please use a shorter nickname!\n");
									}
									else {
										sscanf(buff_nick,"%s",msgstruct->nick_sender);
										msgstruct->type = NICKNAME_NEW;
										strcpy(msgstruct->infos, msgstruct->nick_sender);
										memcpy(nickname,buff_nick, MSG_LEN);

									}
								}
								else if(strcmp(commande, "/who")==0  )
								{
									msgstruct->type = NICKNAME_LIST;
									strcpy(msgstruct->infos, " ");
									strcpy(msgstruct->nick_sender, nickname);
								}
								else if(strcmp(commande, "/whois")==0)
								{

									msgstruct->type=NICKNAME_INFOS;
									strcpy(msgstruct->infos,msg);
									strcpy(msgstruct->nick_sender, nickname); //save the nickname

								}
								else if(strcmp(commande, "/msgall")==0)
								{
									msgstruct->type=BROADCAST_SEND;
									strcpy(msgstruct->infos,msg);
									strcpy(msgstruct->nick_sender, nickname); //save the nickname
								}
								else if(strcmp(commande, "/msg")==0)
								{
									char buffmsg[MSG_LEN];
									memset(buffmsg, 0, MSG_LEN);
									sscanf(msg, "%s %*[^'0']", buffmsg);
									msgstruct->type=UNICAST_SEND;
									strcpy(msgstruct->infos,buffmsg);	//target user
									strcpy(msgstruct->nick_sender, nickname); //save the nickname
								}
								else if(strcmp(commande, "/send")==0)
								{
									char buffmsg[MSG_LEN];
									memset(buffmsg, 0, MSG_LEN);
									memset(file_name,0,MSG_LEN);
									sscanf(msg, "%s %*[^'0']", buffmsg);
									sscanf(msg,"%*s %[^\n]",file_name);
									if (strcmp(file_name,"")==0)
									{
										printf("Il manque le nom du fichier à envoyé !\n");
									}
									else{
										/*Ouverture fichier*/
										if ((file_src = open(file_name,O_RDONLY)) == -1) {
											printf("Le fichier n existe pas\n");
										}else{
											close(file_src);
											msgstruct->type=FILE_REQUEST;
											strcpy(msgstruct->infos,buffmsg);	//target user
											strcpy(msgstruct->nick_sender, nickname); //save the nickname
										}
									}
								}
								else if (request == 2)
								{
									msgstruct->type = FILE_ACCEPT;
									strcpy(msgstruct->infos, file_send_src);
									strcpy(msgstruct->nick_sender, nickname);
									status_recv = 2;
									request = 0;
								}
								else if (request == 3)
								{
									msgstruct->type = FILE_REJECT;
									strcpy(msgstruct->infos, file_send_src);
									memset(file_send_src, 0, NICK_LEN);
									strcpy(msgstruct->nick_sender, nickname);
									request = 0;
								}

								else if(strcmp(commande, "/create")==0)
									{
									char nom_salon[MSG_LEN];
									sscanf(buff, "%*7[^'0']%*c%[^\n]", nom_salon);
									int n = 0;
									for(i=0; nom_salon[i] != '\0'; i++)
									{
										if ((nom_salon[i] == ' ' && nom_salon[i+1]!='\n') || (isdigit(nom_salon[i])==0 && isalpha(nom_salon[i])==0))
										   n++;
									}
									if (n>0)
									{
										printf("Please choose another name!\n"); //espace ou caractère spéciaux
									}

									else if (strlen(nom_salon)>20)
									{
										printf("Please use a shorter name!\n");
									}
									else {
										msgstruct->type = MULTICAST_CREATE;
										strcpy(msgstruct->infos, nom_salon);
										strcpy(msgstruct->nick_sender, nickname); //save the nickname

									}
									}
								else if(strcmp(commande, "/join")==0)
								{
									char bufmsg[MSG_LEN];
									memset(bufmsg, 0, MSG_LEN);
									sscanf(msg, "%s %*[^'0']", bufmsg);
									msgstruct->type = MULTICAST_JOIN;
									strcpy(msgstruct->infos, bufmsg);
									strcpy(msgstruct->nick_sender, nickname); //save the nickname
								}
								/*else if(strcmp(commande, "/channel")==0)
								{
									char chan[MSG_LEN];
									memset(chan, 0, MSG_LEN);
									sscanf(msg, "%s %*[^'0']", chan);
									msgstruct->type=MULTICAST_SEND;
									strcpy(msgstruct->infos,chan);
									strcpy(msgstruct->nick_sender, nickname); //save the nickname
								}*/
								else if(strcmp(commande, "/channel_list")==0)
								{
									msgstruct->type = MULTICAST_LIST;
									strcpy(msgstruct->infos, " ");
									strcpy(msgstruct->nick_sender, nickname);
								}
								else if(strcmp(commande, "/quit")==0)
								{
									strcpy(msgstruct->nick_sender, nickname); //save the nickname
									msgstruct->type=MULTICAST_QUIT;

									char quitt[MSG_LEN];
									memset(quitt, 0, MSG_LEN);
									sscanf(msg, "%s %*[^'0']", quitt);
									strcpy(msgstruct->infos,quitt);

								}

								else{
									msgstruct->type=ECHO_SEND;
									strcpy(msgstruct->nick_sender, nickname); //save the nickname
									strcpy(msgstruct->infos,buff);
								}

							    if (send(sfd, msgstruct, sizeof(struct message), 0) <= 0) {
			             			 exit(EXIT_FAILURE);
		           				 }
								else if(msgstruct->type == 4)   //unicast_send
								{
									strcpy(msgstruct->nick_sender, nickname); //save the nickname
									char mymessage[MSG_LEN];
									sscanf(msg,"%*s %[^\n]",mymessage);
									send(sfd, mymessage, MSG_LEN, 0);
									printf("Message sent!\n");

								}
								else if(msgstruct->type == 11)   //file_send
								{
									strcpy(msgstruct->nick_sender, nickname); //save the nickname

									send(sfd, file_name, MSG_LEN, 0);
									printf("Waiting for target answer ...\n");

								}
								else if(msgstruct->type == 16)   //file_send
								{
									strcpy(msgstruct->nick_sender, nickname); //save the nickname
									send(sfd, file_name, MSG_LEN, 0);
									memset(file_name,0,MSG_LEN);
								}




								/*else if(msgstruct->type == 9)   //multicast_send
								{
									//strcpy(msgstruct->nick_sender, buff_nick); //save the nickname
									char mymsg[MSG_LEN];
									sscanf(msg,"%*s %[^\n]",mymsg);
									send(sfd, mymsg, MSG_LEN, 0);

								}*/
								else if (msgstruct->type == MULTICAST_QUIT)
								{
									if (strcmp(msg,"")==0)
									{
										memset(msgstruct->infos, 0, MSG_LEN);
										strcpy(msgstruct->infos, buff);
										printf("Connection closed %d \n", strcmp(msgstruct->infos, "/quit"));
										shutdown(sfd,SHUT_RDWR);
										close(sfd);
										return ;
									}

								}


							fds[0].revents=0;


					}
				else if(fds[1].revents == POLLIN){
							// Cleaning memory

							memset(message, 0, MSG_LEN);
							int k= recv(fds[1].fd, message, sizeof(message), 0);
          					if ( k <= 0) {
								break;
							}
							sscanf(message, "%s",config);

							if (strcmp(config,"[send_request§]")==0){
								sscanf(message, "%s %[^\n]",config, message);

								request=1;
								sscanf(message, "%s %[^'0']",my_send_port, message);

								sscanf(message, "%s ",file_send_src);
								printf("my send port: %s\n", my_send_port);
								memset(config, 0, 30);
							}

							if (strcmp(config,"[send_accept¤]")==0){
								sscanf(message, "%s %[^\n]",config, message);
								sscanf(message, "%*s %s %s %*[^'0']",target_ip,target_port);
								status_send = 1;
								printf("minjadid\n");
							}

							printf(" %s\n ",message);



						fds[1].revents = 0;
				}
				else if(status_recv==4){
					printf("hana hnaya\n");
					int flags = fcntl(fds[3].fd, F_GETFL);
					fcntl(fds[3].fd, F_SETFL, flags | O_NONBLOCK);
					printf("Listening socket...\n");
					new_conn = accept(recv_sfd,(struct sockaddr*)&cliaddr, &len);
					if (new_conn < 0)
						{
						if (errno != EWOULDBLOCK)
						{
							perror("  accept() failed");
							break;
						}
						break;
					}

					printf("  New incoming connection - %d\n", new_conn);
				}



		}



	}
  int j;
	for (j= 0; j < 4; j++)
  		{
    		if(fds[j].fd >= 0)
      		close(fds[j].fd);
 		 }
}

int main(int argc, char* argv[]) {

	if (argc < 3) {
		fprintf(stderr, "Usage: %s adrIP port \n", argv[0]);
		exit(EXIT_FAILURE);
	}

	int sfd;
	sfd = handle_connect(argv[1], argv[2]);
	printf("Connection with server ... Done!\n");
	printf("[SERVER] : Please login with /nick <your pseudo>\n");
	fflush(stdout);
	poll_client(sfd);
	close(sfd);

	return EXIT_SUCCESS;
}
