Readme.client_existant

jalon3

on going jalon4 échange fichier sans acquittement.

pour sortir uniquement d'un salon il faut faire /quit "nom_salon"
