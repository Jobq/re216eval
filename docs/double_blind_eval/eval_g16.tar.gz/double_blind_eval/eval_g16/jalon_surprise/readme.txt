
Au niveau de l'interface :
dessin lors du lancement du programme, incorporation de couleur

//
Gestion des bugs en cas de ctrl C (pour le send / dans un salon etc)
