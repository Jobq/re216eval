surprise

- Ajouts des couleurs
- Liste des commandes /cmd 
- Liste des utilisateurs salon /who <salon>
