jalon2

Requirements jalon3:
3.1
3.2
3.3
3.4

Le serveur accepte les noms de salon avec caractères spéciaux.

