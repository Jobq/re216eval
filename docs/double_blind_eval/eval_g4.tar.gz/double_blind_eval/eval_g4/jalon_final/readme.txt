Jalon 1 et 2 terminés
Problème dans l'exécution : erreur de segmentation

Jalon 3 en cours :
structure du salon (Salon_t) créée ainsi que :
la liste des salons FirstSalon_t
la fonction ajout de salon : add_Salon
la fonction suppression de salon : delete_Salon
la fonction qui affiche la liste des salons : DisplaySalList
la fonction qui retourne le nombre de clients dans un salon : NbrUserSalle
la fonction qui ajoute un user à un salon : add_user_salon
la fonction qui trouve un salon à l'aide de son id : find_salon 
