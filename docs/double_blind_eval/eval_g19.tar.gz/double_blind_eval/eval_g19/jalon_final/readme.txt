/nick <nickname> :
Si le <nickname> contient des espaces, alors ils seront remplacés par des _.

/create <salle> :
Si le <salle> contient des espaces, alors ils seront remplacés par des _.

/quit :
Si l'utilisateur est dans un salon de discussion, alors le /quit lui permet de quitter ce salon et un second /quit le deconnecte pour de bon.
la commande /quit est la seule commande accessible avant de soumettre un pseudo.

Envoi de messages dans un salon :
Si l'utilisateur est dans un salon et envoi un message précédé par aucune commande, alors ce message sera transmis à tous les participants du salon. Si par contre, il n'est dans aucun salon, alors le serveur lui repondra avec la meme message qu'il a envoyé.

Envoi et reception de fichiers :
[Y/N] doit impéartivement être suivi de Y ou de N en majuscule sinon il affichera [Y/N] jusqu'à avoir une réponse valide.
