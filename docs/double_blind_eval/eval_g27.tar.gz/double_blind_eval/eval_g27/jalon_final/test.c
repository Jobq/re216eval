#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <string.h>
#include <unistd.h>
#include <poll.h>
int main(int argc, char argv[]){
    
    char str[]="/home/file.txt";
    char * strTocken = strtok(str,"/");
    printf("%s\n", strTocken);
    char  tmp[sizeof(strTocken)];
    while(strTocken !=0){
        printf("%s\n", strTocken);
        strcpy(tmp,strTocken);
        strTocken = strtok(NULL, "/");
   
    }
    printf("%s\n",tmp);
    
    return 0;
}