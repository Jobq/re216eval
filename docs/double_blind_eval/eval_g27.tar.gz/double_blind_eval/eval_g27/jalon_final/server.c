#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <string.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <poll.h>
#include <unistd.h>
#include <time.h>

#include "msg_struct.h"

#define  len_msg  1024

// Linked list
struct info{
  int fd;
  char *ip;
  int port;
  char pseudo[NICK_LEN];
  char date[20];
  char salon[NICK_LEN];
  struct info* next;
  struct info* previous;

};




struct info* new_struct_info(int new_fd,struct sockaddr_in * addr_client)
{
    time_t rawtime;
    struct tm * timeinfo;

    time ( &rawtime );
    timeinfo = localtime ( &rawtime );


  struct info* tmp = malloc(sizeof(struct info));
  memset(tmp, 0, sizeof(struct info));

  tmp->fd =   new_fd;
  tmp->ip = inet_ntoa(addr_client->sin_addr);
  tmp->port = ntohs(addr_client->sin_port);
  sprintf(tmp->date,"%d-%d-%d @ %d:%d",timeinfo->tm_mday, timeinfo->tm_mon + 1, timeinfo->tm_year + 1900, timeinfo->tm_hour, timeinfo->tm_min);
  tmp->next = NULL;
  tmp->previous = NULL;
  return(tmp);
}
int existing_nickname(struct info* starter,char* nickname){

  struct info* tmp = starter;
  for (tmp ; tmp != NULL; tmp = tmp->next){
    if(strcmp(nickname, tmp->pseudo)==0){
      return(1);
    }
  }
  return(0);
}


//Linked list Slons
struct salons{

  char name[NICK_LEN];
  struct salons* next;
  struct salons* previous;
  struct info* user;

};


struct salons* new_struct_salon(char* name){

  struct salons* tmp = malloc(sizeof(struct salons));
  memset(tmp, 0, sizeof(struct salons));

  strcpy(tmp->name,name);
  tmp->next = NULL;
  tmp->previous = NULL;
  tmp->user = NULL;

  return(tmp);


}

int existing_SalonName(struct salons* root,char* name){

  struct salons* tmp = root;
  for (tmp ; tmp != NULL; tmp = tmp->next){
    if(strcmp(name, tmp->name)==0){
      return(1);
    }
  }
  return(0);
}

int Join_salon(struct salons* salon,struct info* user){

  struct info* tmp = salon->user;
  while (tmp->next != NULL){
    tmp = tmp -> next;
    printf("In this salon: %s\n",tmp->pseudo );
    if (strcmp(tmp->pseudo,user->pseudo) == 0){
      return 1;
    }
  }
  tmp->next = user;
  user->previous = tmp;
return(0);
}

struct salons* find_salon(struct salons* root, char* name_salon){
  struct salons* tmp;
  for (tmp = root; tmp != NULL; tmp = tmp->next)
  {
    if (strcmp(tmp->name, name_salon)==0){
      return tmp;
    }
  }
  return NULL;
}

int leave_channel(struct salons* salonRoot, struct info * user){
  struct salons* tmp;
  for (tmp = salonRoot; tmp != NULL; tmp = tmp->next)
  {
    if (strcmp(tmp->name, user->salon) == 0 && strcmp(tmp->user->pseudo, user->pseudo) == 0){
      tmp->previous->next = tmp->next;
      tmp->next->previous = tmp->previous;
      memset(user->salon, 0, NICK_LEN);
      free(tmp);
      return EXIT_SUCCESS;
    }
  }
  return EXIT_FAILURE;
}

int main(int argc, char* argv[]) {

    if(argc != 2){
        printf("PORT ADRESS PLEASE!\n");
        return 1;
    }
    // 1. socket tcp
    int sock = socket(AF_INET, SOCK_STREAM, 0); // SOCK_DGRAM for UDP SOCK_STREAM for TCP
    if (sock == -1) {
        printf("Error creating socket !\n");
        return 1;
    }
    // 2. sockaddr_in with INADDRANY for adress
    struct sockaddr_in saddr;
    saddr.sin_family = AF_INET;
    saddr.sin_port = htons(atoi(argv[1]));
    saddr.sin_addr.s_addr = INADDR_ANY;

    // 3. bind()
    int resultBind = bind(sock, (struct sockaddr*)&saddr, sizeof(saddr));
    if (resultBind == -1) {
        perror("bind()");
        puts(strerror(errno));
        return 1;
    }

    // 4. Listen
    int backlogs = 10; // Number of connections possible
    int resultListen = listen(sock, backlogs);
    if (resultListen == -1) {
        perror("ERROR LISTENING");
        return 1;
    }
    // multi clients
    struct pollfd fds[512];
    memset(&fds,0,sizeof(fds));
    fds[0].fd = sock;
    fds[0].events = POLLIN;
    struct sockaddr_in addr_client;
    socklen_t len ;
    memset(&addr_client,0,sizeof(struct sockaddr_in));

    int nfds = 1;  //nombre of fds connecting
    int new_fd;
    int current_size = 0;

    struct info* starter = malloc(sizeof(struct info));
    memset(starter, 0, sizeof(struct info));
    starter->next = NULL;

    struct salons* root = malloc(sizeof(struct salons));
    memset(root, 0, sizeof(struct salons));
    root->next = NULL;

    char buffer[len_msg]={};
    char buffer_2[len_msg]={};

    while(1){
        int i =0;
        poll(fds, nfds,-1);
        current_size = nfds;
        for(i; i< current_size; i++){
            if(fds[i].revents == POLLIN){
                if(fds[i].fd == sock){

                  new_fd = accept(sock, (struct sockaddr*) &addr_client, &len);
                  if(new_fd == -1){
                    perror("Accepted error");
                    return 1;
                  }
                  printf("new connection is ACCEPTED \n");
                  fflush(stdout);
                  fds[nfds].fd = new_fd;
                  fds[nfds].events = POLLIN;
                  nfds++;
                  getpeername(new_fd,(struct sockaddr*) &addr_client,&len);



                  struct info* tmp = starter;
                  while(tmp->next!=NULL){

                    tmp = tmp->next;
                  }
                  struct info * new_client = new_struct_info(new_fd, &addr_client);

                  //Add new client to the linked list
                  tmp->next = new_client;
                  new_client->previous = tmp;


                }


                /**************************************/
                /*****  ELSE LISTENING TO CLIENT  *****/
                /**************************************/


                 else {

                   //FINDING THE STRUCT FOR CURRENT CLIENT
                  struct info * current_client = starter;
                  for (current_client; current_client->fd != fds[i].fd; current_client=current_client->next);

                  // receive
                  struct message* msg_rcv = malloc(sizeof(struct message));
                  memset(msg_rcv,0,sizeof(struct message));


                  // char buffer[len_msg]; ---------------------------------------
                  memset(buffer,0,len_msg);

                  int resultRecv = recv(fds[i].fd, msg_rcv, sizeof(struct message), 0);
                  printf("[+] [Client] infos : %s, nick_sender : %s, pldl_len : %i, type %s\n" ,msg_rcv->infos,msg_rcv->nick_sender,msg_rcv->pld_len,msg_type_str[msg_rcv->type]);

                  if ( msg_rcv->pld_len > 0 ) {
                    int resultRecv_2 = recv(fds[i].fd, buffer_2, msg_rcv->pld_len, 0);

                    if (resultRecv_2 <= 0) {
                      perror("[-] error recieve buffer ");
                      close(fds[i].fd);
                      break;
                    }

                  }

                  if (resultRecv <= 0) {
                    perror("[-] error recieve struct");
                    close(fds[i].fd);
                    break;
                  }

                  char nick[NICK_LEN];

                  switch (msg_rcv->type) {
                    case NICKNAME_NEW:

                      if (existing_nickname(starter, msg_rcv->infos) == 0) {
                        sprintf(buffer, "[Server] : Welcome on the chat %s\n", msg_rcv->infos);
                        strcpy(current_client->pseudo, msg_rcv->infos);
                      } else if(existing_nickname(starter, msg_rcv->infos) == 1) {
                        strcpy(buffer, "[Server] : Sorry nickname already in use");
                        printf("[-] Nickname in use\n");
                      }
                      // }
                      break;

                    case NICKNAME_LIST:;
                      struct info * tmp_starter = starter->next;
                      // char tmp_buffer[len_msg];
                      strcpy(buffer,"[Server] : Online users are:\n");
                      for(tmp_starter; tmp_starter != NULL; tmp_starter=tmp_starter->next ){
                        strcat(buffer,"\t");
                        strcat(buffer,tmp_starter->pseudo);
                        strcat(buffer,"\n");

                      }
                      break;

                    case NICKNAME_INFOS:;
                      char Port[len_msg];
                      struct info * c = starter->next;
                      for(c; c != NULL; c=c->next ){
                        if(strcmp(c->pseudo,msg_rcv->infos) == 0){
                          sprintf(buffer,"[Server] :  %s connected since %s with IP %s and port number %i\n",
                          c->pseudo, c->date, c->ip, c->port);
                        }
                      }
                      break;

                    case BROADCAST_SEND:;

                      struct info * s = starter->next;
                      for(s; s != NULL; s=s->next ){

                        if(s->fd != current_client->fd){
                          memset(buffer,0,sizeof(buffer));
                          sprintf(buffer,"[%s] %s \n",msg_rcv->nick_sender,buffer_2);
                          int resultSend_2 = send(s->fd,buffer,strlen(buffer),0);
                          memset(buffer,0,sizeof(buffer));
                        }
                        else
                        {
                          strcpy(buffer,"[Server] : Sent to all\n");
                        }

                      }

                    break;

                    case UNICAST_SEND:;
                      int sendTo;
                      int flag = 0;
                      struct info * p = starter->next;
                      for(p; p != NULL; p=p->next ){

                        if(strcmp(msg_rcv->infos,p->pseudo) == 0){
                          flag =1;
                          sendTo = p->fd;
                          sprintf(buffer,"[%s] %s \n",msg_rcv->nick_sender,buffer_2);
                          memset(buffer_2,0,sizeof(buffer_2));
                        }
                      }

                      if (flag == 1) {
                        int resultSend_2 = send(sendTo,buffer,strlen(buffer),0);
                        memset(buffer, 0, sizeof(buffer));
                        if (resultSend_2 <= 0) {
                          sprintf(buffer,"[Server]: Could not reach user : %s\n",msg_rcv->infos);
                        }  else {
                          strcpy(buffer,"[Server]: Sent to destination\n");
                        }
                      } else {
                        memset(buffer,0,sizeof(buffer));
                        sprintf(buffer,"[Server]: user %s does not exist!\n",msg_rcv->infos);
                      }
                    break;

                    case ECHO_SEND:
                      strcpy(buffer,buffer_2);
                    break;

                    //****************************//
                    //********* Salons ***********//
                    //****************************//

                    case MULTICAST_CREATE:;

                      struct salons* tmp = root;
                      struct info * t =  new_struct_info(current_client->fd, &addr_client);
                      //tmp->user = t;

                      if (existing_SalonName(tmp, msg_rcv->infos) == 0) {
                        while(tmp->next!=NULL){

                          tmp = tmp->next;
                        }
                        struct salons *new_salon = new_struct_salon(msg_rcv->infos);
                        //Add new salon to the linked list
                        tmp->next = new_salon;
                        new_salon->previous = tmp;
                        struct info* user_create = malloc(sizeof(struct info));
                        memset(user_create,0,sizeof(struct info));
                        new_salon->user = user_create;
                        printf("[+] A new salon %s has been created\n",msg_rcv->infos);
                        sprintf(buffer,"[Server] : You have created a new salon %s\n",msg_rcv->infos);

                        //Join Salon Created
                        strcpy(t->pseudo , current_client->pseudo);
                        if(Join_salon(new_salon,t) == 0){
                          sprintf(buffer,"[Server] : You have joined %s \n",msg_rcv->infos);
                          strcpy(current_client->salon,msg_rcv->infos);
                        }
                      }
                      else{
                        strcpy(buffer,"[Server]: Salon name is already used\n");
                      }


                    break;

                    //Join_salon
                    case MULTICAST_JOIN:;
                    if (existing_SalonName(tmp, msg_rcv->infos) != 0){
                      struct salons* salon_to_join = find_salon(root,msg_rcv->infos);
                      struct info * t =  new_struct_info(current_client->fd, &addr_client);
                      strcpy(t->pseudo , current_client->pseudo);
                      if(Join_salon(salon_to_join,t) == 0){
                        sprintf(buffer,"[Server] : You have joined %s \n",msg_rcv->infos);
                        strcpy(current_client->salon,msg_rcv->infos);
                      }
                      else{
                        sprintf(buffer,"[Server]: You already are in salon %s \n",msg_rcv->infos);
                      }
                    }
                    else{
                      strcpy(buffer,"[Server]: Salon name does not exist");
                    }

                    break;

                    //Liste of salons
                    case MULTICAST_LIST:;
                      struct salons * sl = root->next;
                      // char tmp_buffer[len_msg];
                      strcpy(buffer,"[Server] : Channels are:\n");
                      for(sl; sl != NULL; sl=sl->next ){
                        strcat(buffer,"\t");
                        strcat(buffer,sl->name);
                        strcat(buffer,"\n");

                      }
                      break;



                  case MULTICAST_QUIT:;

                    int inchannel = strcmp(current_client->salon,"");
                    int rc = leave_channel(root, current_client);

                    if ( inchannel == 0 ){
                      close(fds[i].fd);
                      fds[i].fd = -1;
                    }

                    break;

                    
                    
                    
                    case MULTICAST_SEND:
                      if (existing_SalonName(root, current_client->salon) != 0){
                        struct salons * broadcast_salon;
                        broadcast_salon = find_salon(root,current_client->salon);

                        struct info * s = broadcast_salon->user->next;
                        for(s; s != NULL; s=s->next ){

                          if(s->fd != current_client->fd){
                            memset(buffer,0,sizeof(buffer));
                            sprintf(buffer,"[%s] [%s] %s \n",current_client->salon,msg_rcv->nick_sender,buffer_2);
                            int resultSend_2 = send(s->fd,buffer,strlen(buffer),0);
                            memset(buffer,0,sizeof(buffer));
                          }
                          else
                          {
                            strcpy(buffer,"[Server] : Sent to all the salon\n");
                          }

                        }
                    }
                    break;

                    //************************************//
                    //********* SENDING FILES ***********//
                    //**********************************//

                  case FILE_REQUEST:;
                    int sendingTo;
                      int flag2 = 0;
                      struct info * z = starter->next;
                      for(z; z != NULL; z=z->next ){

                        if(strcmp(msg_rcv->infos,z->pseudo) == 0){
                          flag2 =1;
                          sendingTo = z->fd;
                          sprintf(buffer,"[%s] wants you to accept the transfer of the file named %s. Do you accept? [Y/N] \n",msg_rcv->nick_sender,buffer_2);
                          memset(buffer_2,0,sizeof(buffer_2));
                        }
                      }

                      if (flag2 == 1) {
                        int resultSend_2 = send(sendingTo,buffer,strlen(buffer),0);
                        memset(buffer, 0, sizeof(buffer));
                        if (resultSend_2 <= 0) {
                          sprintf(buffer,"[Server]: Could not reach user : %s\n",msg_rcv->infos);
                        }  else {
                          strcpy(buffer,"[Server]: Sent to destination\n");
                        }
                      } else {
                        memset(buffer,0,sizeof(buffer));
                        sprintf(buffer,"[Server]: user %s does not exist!\n",msg_rcv->infos);
                      }

                    break;

                    default:
                      break;
                    }

                    //send
                    if(fds[i].fd != -1){
                      int resultSend = send(fds[i].fd, buffer, strlen(buffer), 0);
                      printf("sending to %s \n",current_client->pseudo);
                      memset(buffer,0,sizeof(buffer));
                      if (resultSend == -1) {
                        perror("ERROR SEND: ");
                        break;
                      }
                    }

                    //Close current client and deleting it from the linked list
                    else {
                      // close(fds[i].fd);
                      printf("[-] User %s left the chat\n", current_client->pseudo);
                      if(current_client->next != NULL){
                      current_client->next->previous = current_client->previous;
                      }
                      if(current_client->previous != NULL){
                      current_client->previous->next = current_client->next;
                      }
                      free(current_client);
                    }


                }
            }
        }
    }
    // 5.Free memory

    close(sock);


    return 0;
}
