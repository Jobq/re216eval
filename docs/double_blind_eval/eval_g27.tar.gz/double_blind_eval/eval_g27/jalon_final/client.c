#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <string.h>
#include <unistd.h>
#include <poll.h>
#include "msg_struct.h"

//Global variables
#define len_msg  1024
char nickname[NICK_LEN];
int salon = 0;

int handle_connect(char *address, char *port) {
	struct addrinfo hints, *result, *rp;
	int sfd;
	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	if (getaddrinfo(address, port, &hints, &result) != 0) {
		perror("getaddrinfo()");
		exit(EXIT_FAILURE);
	}
	for (rp = result; rp != NULL; rp = rp->ai_next) {
		sfd = socket(rp->ai_family, rp->ai_socktype,rp->ai_protocol);
		if (sfd == -1) {
			continue;
		}
		if (connect(sfd, rp->ai_addr, rp->ai_addrlen) != -1) {
			break;
		}
		close(sfd);
	}
	if (rp == NULL) {
		fprintf(stderr, "Could not connect\n");
		exit(EXIT_FAILURE);
	}
	freeaddrinfo(result);
	return sfd;
}



int handle_input(int fd){

    struct message* msg_send = malloc(sizeof(struct message));
    memset(msg_send,0,sizeof(struct message));

    char readBuffer[len_msg]={};
    read(0,readBuffer,len_msg);

    char sendBuffer[len_msg]={};

    char command[8];
    char arg1[NICK_LEN];
    char arg2[NICK_LEN];
    int correct_nickname = 1;
    int nb_arg ;

    strcpy(msg_send->nick_sender,nickname);


    if (readBuffer[0] == '/'){ //it's a command

        nb_arg = sscanf(readBuffer,"/%s %s %s\n",command,arg1,arg2);

        if (strcmp(command,"nick") == 0){

            if(nb_arg > 2){
                printf("[-] Nickname should not contain space!\n");

            } else if ( strlen(arg1) > NICK_LEN || strlen(arg1) < 0 ){
                printf("[-] Message too big or too small! \n");

            }
            else{
                strcpy(msg_send->infos,arg1);

                msg_send->type = NICKNAME_NEW;
                msg_send->pld_len = 0;
            }

        }
        else if(strcmp(command,"who") == 0){
            strcpy(msg_send->infos,"");
            msg_send->type = NICKNAME_LIST;
            msg_send->pld_len = 0;

        }
         else if(strcmp(command,"whois") == 0){
            if(nb_arg<2){
                printf("please write a nickname");
            }
            else{
                strcpy(msg_send->infos,arg1);
                msg_send->type = NICKNAME_INFOS;
                msg_send->pld_len = 0;

            }
        }
        else if(strcmp(command,"msgall") == 0){
            strcpy(msg_send->infos,"");
            msg_send->type = BROADCAST_SEND;
            strcpy(sendBuffer,readBuffer + 8);
            msg_send->pld_len = strlen(sendBuffer);
        }
        else if(strcmp(command,"msg") == 0){
            strcpy(msg_send->infos,arg1);
            msg_send->type = UNICAST_SEND;
            strcpy(sendBuffer,readBuffer + 5 + strlen(arg1));
            msg_send->pld_len = strlen(sendBuffer);
        }
        else if(strcmp(command,"quit") == 0){
            msg_send->type = MULTICAST_QUIT;
            msg_send->pld_len = 0;
            if (nb_arg ==1){
                strcpy(msg_send->infos,""); 
            }
			else{
				strcpy(msg_send->infos,arg1);
			}
        }
        //****************************//
        //********* Salons ***********//
        //****************************//
				//Create
        else if(strcmp(command,"create") == 0){
            printf("create\n");
            if(nb_arg > 2){
                printf("[-] Salon name should not contain space!\n");

            } else{
            strcpy(msg_send->infos,arg1);
            msg_send->type = MULTICAST_CREATE;
            msg_send->pld_len = 0;
						salon = 1;
            }
        }
        //Channel List
        else if(strcmp(command,"channel_list") == 0){
            msg_send->type = MULTICAST_LIST;
            msg_send->pld_len = 0;
        }

        // Join
        else if(strcmp(command,"join") == 0){
            printf("join\n");
            if(nb_arg > 2){
                printf("[-] Salon name should not contain space!\n");

            } else{
            strcpy(msg_send->infos,arg1);
            msg_send->type = MULTICAST_JOIN;
            msg_send->pld_len = 0;
            salon = 1;
            }
        }

        //************************************//
        //********* SENDING FILES ***********//
        //**********************************//

        else if(strcmp(command,"send") == 0){
            msg_send->type = FILE_REQUEST;
            strcpy(msg_send->infos,arg1);

            char str[sizeof(arg2)];
            strcpy(str,arg2);
            char * strTocken = strtok(str,"/");
            char  tmp[sizeof(strTocken)];
            while(strTocken !=0){
                printf("%s\n", strTocken);
                strcpy(tmp,strTocken);
                strTocken = strtok(NULL, "/");
            }
            strcpy(sendBuffer,tmp);
            msg_send->pld_len = sizeof(tmp) ;

       }
    }

    else {
        if (salon == 0){
            strcpy(msg_send->infos,"");
            msg_send->type = ECHO_SEND;
            msg_send->pld_len = strlen(readBuffer);
            strcpy(sendBuffer,readBuffer);
        }
        else{
            strcpy(msg_send->infos,"");
	        msg_send->type = MULTICAST_SEND;
	        msg_send->pld_len = strlen(readBuffer);
            strcpy(sendBuffer,readBuffer);
        }
    }

    printf("[+] [Client] infos : %s, nick_sender : %s, pldl_len : %i, type %s\n" ,msg_send->infos,msg_send->nick_sender,msg_send->pld_len,msg_type_str[msg_send->type]);

    int resultSend = send(fd, msg_send, sizeof(struct message), 0);

    if (msg_send->pld_len > 0)
    {
        int resultSend_2 = send(fd,sendBuffer, msg_send->pld_len, 0);

        if (resultSend_2 == -1) {
            perror("ERROR SEND msg: ");
            return -1;
        }
    }


    if (resultSend == -1) {
        perror("ERROR SEND struct: ");
        return -1;

    }


     if (msg_send->type == MULTICAST_QUIT && nb_arg == 1){
        printf("connection closed\n");
        return -1;
    }

    return 1;
}

int main(int argc, char* argv[]) {
    if(argc != 3){
        printf("Please write IP AND PORT ADRESSES!\n");
        return 1;
    }

    int sock;
	sock = handle_connect(argv[1], argv[2]);
    printf("[Server] : please login with /nick <your pseudo> \n");

    //POLL
    struct pollfd fds[2];
    fds[0].fd = sock;
    fds[0].events=POLLIN;
    fds[1].fd = 0;
    fds[1].events=POLLIN;

    int close_client = 1;

    char Buffer[len_msg]={};

    //equal
    // char* readBuffer = (char*)malloc(len_msg) ;
    // memset(readBuffer,0,strlen(readBuffer));

    char tmp_nickname[NICK_LEN];


    while(close_client == 1){
        poll(fds,2,-1);
        int i;
        for(i =0;i<2;i++){
            if(fds[i].revents == POLLIN){
                if(fds[i].fd==sock){

                    char* messageToRecv = (char*)malloc(len_msg);
                    memset(messageToRecv,0,len_msg);

                    int resultRecv = recv(fds[i].fd, messageToRecv, len_msg, 0);

                    if (resultRecv <= 0) {
                        perror("connection closed with ");
                        close_client = 0;
                        break;
                    }

                    printf("%s \n", messageToRecv);
                    if(sscanf(messageToRecv,"[Server] : Welcome on the chat %s\n",tmp_nickname) == 1){
                        strcpy(nickname,tmp_nickname);
                        printf("%s\n",nickname);
                    }
                    // else{
                    //     strcpy(nickname,NULL);
                    //     printf("Nickename in use\n");
                    // }


                }
                else {

                    //handle input from user
                    close_client = handle_input(sock);


                }
            }

        }
    }



    // 5.Free memory
    //free(messageToRecv);
    //free(readBuffer);
    //freeaddrinfo(result);
    close(sock);

    return 0;
}
