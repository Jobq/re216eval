Jalon 1 fini

Jalon 2 commencé mais problème de Seg fault quand enregistrement pseudo
Le problème de segmentation fault se situe à la ligne 183, et correspond à une erreur dans la fonction strcpy et plus précisement avec la structure client.  
