Jalon4

L'envoie de fichier est géré avec des threads, ce qui peut provoquer des comportements étranges,
mais permet d'utiliser les autres fonctionnalités pendant l'échange de fichiers volumineux. 
