fonctions surprises :
  - affichage de l'heure de réception des messages dans le client
  - fct /ans pr répondre plus rapidement au dernier /msg reçu
    (pour tester : envoyer un /msg à un client B avec un  client A
                   répondre avec /ans <msg de réponse> dans le client B )

envoi de fichier avec un code de version ultérieure à celui de jalon_final, ie, pas avec des threads.               
