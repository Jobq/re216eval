Code à évaluer dans Jalon_surprise

Dernier jalon réalisé : Jalon4

Fonctionnalités :

Envoi de fichier : Drag & Drop, Loading Bar, envoi de grand fichier possible.
