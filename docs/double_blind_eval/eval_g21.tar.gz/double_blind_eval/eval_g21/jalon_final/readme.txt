Jalon 1 , Jalon 2 , Jalon 3 ont été faits dans leur intégralité   

Pour le Jalon 4 , les sous taches faites sont les suivantes :
Pour effectuer un FILE REQUEST , la commande est /sennd user "chemin vers le fichier".
par exemple si le client envoie /sennd user2 /home/user/file.txt , le serveur envoie au user 2 "user1 wants you to accept the transfer of the file named "file.txt". Do you accept? [Y/N]" , si le user 2 répond par N , le user 1 recoit "user2 cancelled file transfer." Si le user 2 répond par Y le user1 reçoit "user2 accepted file transfert. Connecting to user2 and sending the file ..." . 
Ce que nous avons fait pour établir la connexion entre les deux clients est mis en commentaire dans le code de client.c 

   
