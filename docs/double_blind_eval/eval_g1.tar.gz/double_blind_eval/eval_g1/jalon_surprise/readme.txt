Fonctionnalités ajoutées : 

/sendall <nom_du_salon> <fichier> permet à un client membre d'un salon 
d'envoyer un fichier à tous les autres membres du salon. Comme précedemment
les autres utilisateurs peuvent accepter ou refuser. Des fichiers inbox ont
été créés pour chaque client (nom : inbox<pid_du_processus_client>)
