Les jalons 1 à 4 ont été réalisés. 

Remarques : 
Dans le cas où on fait un /nick, /create, /join, /quit (pour un salon) et 
que l'on envoie un message dans un salon, le client réagit en fonction de la 
chaîne de caractère envoyée par le serveur (la chaîne de caractère commence
 par 0 ou 1). Il peut donc y avoir des problèmes de compatibilités lors 
des tests qui mélangent clients et serveurs.   
