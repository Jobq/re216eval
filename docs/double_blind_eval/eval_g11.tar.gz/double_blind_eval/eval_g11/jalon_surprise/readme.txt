Chiffrement des messages envoyé entre deux clients pour rendre la lecture impossible par le serveur
