jalon surprise:

Ajout de la commande /help qui liste en fonction de la position du client 
(soit dans un salon ou pas), les commandes convenables à utiliser.

(laila)
