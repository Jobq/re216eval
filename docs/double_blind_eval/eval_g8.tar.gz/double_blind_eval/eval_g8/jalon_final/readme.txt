Jalon3

Il manque la suppression d'un membre qui quitte le salon pour en créer/joindre un autre.
 
Pour quitter un serveur il faut ffaire /quit <nom_serveur>
