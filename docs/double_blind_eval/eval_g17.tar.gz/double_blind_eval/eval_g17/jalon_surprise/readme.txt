jalon3 + req 2 et 4 Jalon 4  
Tout le code à évaluer se trouve dans le jalon_surprise.

Fonctionnalités rajoutées dans jalon surprise:
--Notification de tous les utilisateurs lors de la déconnexion de l'un des
 clients à tester en connectant plusieurs clients et en déconnectant un.
--Ajout commande Help à utiliser à tester en tapant /help: permet 
d'afficher des commandes possibles
